//<![CDATA[
function image_resizer(threshold_width)
{
  var new_w, new_h;

  for (var i = 0; i < document.images.length; i++)
  {
    if(document.images[i].offsetWidth > threshold_width)
    {
      new_w = threshold_width;
      new_h = Math.round ((document.images[i].offsetHeight / document.images[i].offsetWidth) * new_w);
    
      document.images[i].style.width = new_w + 'px';
      document.images[i].style.height = new_h + 'px';
    }
  }
}
//]]>