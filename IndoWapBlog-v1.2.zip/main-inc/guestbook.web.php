<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

$page=$_GET['page'];
$total=mysql_result(mysql_query("select count(*) from guestbook where status='1'"), 0);
$gp = ceil($total / $site['num_post_main']);

if (empty($page))
{
$page=$gp;
}
if ($page=='0')
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;

$head_title='Buku Tamu';
include 'main-inc/header.web.php';
echo '<div id="content">
<div id="comments">
<h2>Buku Tamu</h2>';
if ($user_id)
{
$nama=$user_name;
$email=$user_email;
$uid=$user_id;
}
else
{
$nama=$_POST['name'];
$email=$_POST['email'];
$uid='0';
}
$pesan=$_POST['message'];
$url=$_POST['url'];
if (!empty($url))
{
$url=str_replace('http://','',$url);
$url='http://'.$url.'';
}
$comment_mod=$site['comment_mod'];
if ($comment_mod == '1')
{
 if ($is_author || $is_admin)
$sts='1';
else
$sts='1';
}
else
{
$sts='1';
}
$code=intval($_POST['captcha']);

if (isset($_POST['guestbook']))
{

if ($code != $_SESSION['captcha_code'])
$hsl='Kode keamanan yang Anda masukan tidak benar';

if (mb_strlen($pesan) < 2 || mb_strlen($pesan) > 500)
$hsl='Pesan minimal 2 dan maksimal 500 karakter';
if (empty($pesan))
$hsl='Silakan masukan pesan Anda';
if (empty($email))
$hsl='Silakan masukam Email Anda';
elseif (mb_strlen($email) < 5 || mb_strlen($email) > 250)$hsl='Panjang email minimal 5 dan maksimal 250 karakter';
if (!eregi("^[a-z0-9\._-]+@[a-z0-9\._-]+\.[a-z]{2,4}\$", $email))
$hsl='Alamat Email tidak benar';
if (mb_strlen($nama) < 2 || mb_strlen($nama) > 30)
$hsl='Nama minimal 2 dan maksimal 30 karakter';
if (empty($nama))
$hsl='Silakan masukan nama Anda';
if (empty($hsl))
{

mysql_query("insert into `guestbook` set `user_id`='".$uid."', `name`='".mysql_real_escape_string($nama)."', `email`='".mysql_real_escape_string($email)."', `site`='".mysql_real_escape_string($url)."', `text`='".mysql_real_escape_string($pesan)."', status='".$sts."', `time`='".time()."'") or die(mysql_error());
if ($sts == 1)
$hsl='Pesan Anda berhasil ditambahkan';
else
$hsl='Pesan terkirim dan akan ditampilkan setelah disetujui administrator';
}
echo '<ol style="padding: 0px; margin: 0px; background: #dd9900;"><li>'.$hsl.'</li></ol>';
}

if ($total != 0)
{
$req=mysql_query("select * from guestbook where status='1' order by time asc limit $limit,$max_view");
while ($res=mysql_fetch_array($req))
{
echo '<div class="comment">
<p class="title"><strong><a href="'.htmlentities($res['site']).'" rel="nofollow">'.htmlspecialchars($res['name']).'</a></strong>
<small> ['.waktu($res['time']).']</small></p>
<p><small>'.bbsm($res['text']).'</small></p>
</div>';
}
}
else
{
echo '<div class="comment">
<p class="title"><strong>'.htmlspecialchars($site['name']).'</strong></p><p>Belum ada pesan pada Buku Tamu. Kenapa Anda tidak menjadi penulis pertama?</p></div>';
}
echo '<h2><a name="new_entry">Tulis Baru</a></h2>
<form action="'.$site['url'].'/guestbook.xhtml" method="post">';
$rdr=''.$site['url'].$_SERVER['REQUEST_URI'].'';
echo '<p>';
if (!$user_id)
{
echo '[<a href="'.$site['url'].'/login.php?redir='.base64_encode($rdr).'" rel="nofollow">Masuk</a>]<br/>';
}
echo 'Nama: <br/>';
if ($user_id)
{
echo '<b>'.htmlspecialchars($user_name).'</b>';
}
else
{
echo '<input type="text" name="name" value=""/>';
}
echo '<br/>
Email:<br/>';
if ($user_id)
{
echo '<b>'.$user_email.'</b>';
}
else
{
echo '<input type="text" name="email" value=""/>';
}
echo '<br/>
Situs:<br/>
<input type="text" name="url" value="'.$user_site.'"/><br/>
Pesan:<br/>
(Kamu bisa menggunakan <a href="'.$site['url'].'/bbsm.php?iwb=bbcode">BBCode</a> dan <a href="'.$site['url'].'/bbsm.php?iwb=smiley">Smiley</a>.)<br/>
<textarea name="message" rows="4"/></textarea>
<br/>';

$_SESSION['captcha_code'] = rand(1000, 9999);
echo 'Keamanan:<br/>
<img src="'.$site['url'].'/captcha.php" alt="Reload...."/><br/>(Masukan kode keamanan)<br/>
<input type="text" name="captcha" value=""/><br/>';
echo '<input name="guestbook" type="submit" value="Simpan"/>
</p>
</form>
</div>';
$link=''.$site['url'].'/guestbook/page/';
$q='.xhtml';

if(empty($page))
$page='1';
$pages=Ceil($total/$max_view);
if ($pages>1)
{
echo '<div id="pagination_links">Halaman:<br /><div id="pagination_links">';
for ($i = 1; $i <= $pages; $i++)
{
if ($page==$i)
{$num=' ['.$i.'] ';}else{ $num=' [<a href="'.$link.''.$i.''.$q.'">'.$i.'</a>] ';}
echo $num;}
echo '</div></div>';
}
echo '</div>';
include 'main-inc/footer.web.php';

?>