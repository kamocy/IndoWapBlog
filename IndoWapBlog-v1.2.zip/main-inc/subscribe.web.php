<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');
$action=isset($_GET['action']) ? trim($_GET['action']) : '';
switch ($action)
{
case 'unsubscribe':
$code=$_GET['code'];
$cek=mysql_query("select * from subscribe where code='".mysql_real_escape_string($code)."' limit 1;");
if (mysql_num_rows($cek) == 0)
{
$hasil='Kode tidak benar!';
}
else
{
mysql_query("delete from subscribe where code='".$code."'");
$hasil='Anda telah berhenti berlanggan.';
}
$head_title='Berhenti Berlangganan';
include 'main-inc/header.web.php';
echo '<div id="content"><div class="post-single"><h2>Berhenti Berlangganan</h2><div style="float: left;"></div>';
echo '<p>'.$hasil.'</p>';
echo '<div style="float: left;"></div></div></div>';
include 'main-inc/footer.web.php';
break;

case 'confirm':
$code=$_GET['code'];
$cek=mysql_query("select * from subscribe where code='".mysql_real_escape_string($code)."' limit 1;");
if (mysql_num_rows($cek) == 0)
{
$hasil='Kode konfirmasi tidak benar!';
}
else
{
$res=mysql_fetch_array($cek);
$tim=time();
$cod=''.$tim.rand(10000, 99999).'';
mysql_query("update subscribe set status='1', code='".$cod."', time='".$tim."' where id='".$res['id']."'");
$hasil='Konfirmasi berlangganan berhasil diselesaikan.';
}
$head_title='Konfirmasi Berlangganan';
include 'main-inc/header.web.php';
echo '<div id="content"><div class="post-single"><h2>Konfirmasi Berlangganan</h2><div style="float: left;"></div>';
echo '<p>'.$hasil.'</p>';
echo '<div style="float: left;"></div></div></div>';
include 'main-inc/footer.web.php';

break;
case 'new_posts':

if (isset($_POST['subscribe']))
{
$my_email=$_POST['my_email'];
if (mb_strlen($my_email) < 2 || mb_strlen($my_email) > 250)
$error='Panjang email maksimal 250 karakter';
if (!eregi("^[a-z0-9\._-]+@[a-z0-9\._-]+\.[a-z]{2,4}\$", $my_email))
$error='Alamat email tidak benar';if (empty($my_email))
$error='Silakan masukan alamat email';
if (empty($error))
{
$cek_email=mysql_query("select * from subscribe where email='".mysql_real_escape_string($my_email)."' and status='1'");
if (mysql_num_rows($cek_email) != 0)
{
$cek_sub=mysql_query("select * from subscribe where email='".mysql_real_escape_string($my_email)."' and sub='new_posts'");
if (mysql_num_rows($cek_sub) != 0)
{
$hasil='Sebelumnya Anda telah berlangganan posting terbaru';
}
else
{
$tim=time();
$cod=''.$tim.rand(10000, 99999).'';
mysql_query("insert into subscribe set email='".mysql_real_escape_string($my_email)."', sub='new_posts', status='1', code='".$cod."', time='".$tim."'");
$hasil='Anda berhasil berlangganan posting terbaru';
}
}
else
{
$cek_sub=mysql_query("select * from subscribe where email='".mysql_real_escape_string($my_email)."' and sub='new_posts'");
if (mysql_num_rows($cek_sub) != 0)
{
$res=mysql_fetch_array($cek_sub);
$adm=mysql_fetch_array(mysql_query("select * from user where admin='1' limit 1;"));

$email = $my_email;
$subject="Konfirmasi Berlangganan";
$pesan="Jika Anda telah mencoba berlangganan Posting terbaru pada ".$site['name']." silakan konfirmasikan berlangganan dengan mengklik link berikut...\r\n\r\n".$site['url']."/subscribe/".$res['code']."\r\n\r\n";
$pesan .= "\r\n\r\n";
$pesan .= "\r\nTerima Kasih\r\n";
$pesan .= $site['name'];
$pesan .= "\r\n\r\n";
$pesan .= $site['url'];
$dari = "From: ".$site['name']." <".$adm['email'].">\r\n";
$dari .= "X-sender: ".$site['name']." <".$adm['email'].">\r\n";
$dari .= "Content-type:text/plain; charset=iso-8859-1\r\n";
$dari .= "MIME-Version: 1.0\r\n";
$dari .= "Content-Transfer-Encoding: 8bit\r\n";
$dari .= "X-Mailer: PHP v.".phpversion();
mail($email,$subject,$pesan,$dari);

$hasil='Silakan klik link konfirmasi berlangganan yang telah kami kirim ke email Anda';
}
else
{
$tim=time();
$cod=''.$tim.rand(10000, 99999).'';
mysql_query("insert into subscribe set email='".mysql_real_escape_string($my_email)."', sub='new_posts', status='0', code='".$cod."', time='".$tim."'");

$adm=mysql_fetch_array(mysql_query("select * from user where admin='1' limit 1;"));

$email = $my_email;
$subject="Konfirmasi Berlangganan";
$pesan="Jika Anda telah mencoba berlangganan Posting terbaru pada ".$site['name']." silakan konfirmasikan berlangganan dengan mengklik link berikut...\r\n\r\n".$site['url']."/subscribe/".$cod."\r\n\r\n";
$pesan .= "\r\n\r\n";
$pesan .= "\r\nTerima Kasih\r\n";
$pesan .= $site['name'];
$pesan .= "\r\n\r\n";
$pesan .= $site['url'];
$dari = "From: ".$site['name']." <".$adm['email'].">\r\n";
$dari .= "X-sender: ".$site['name']." <".$adm['email'].">\r\n";
$dari .= "Content-type:text/plain; charset=iso-8859-1\r\n";
$dari .= "MIME-Version: 1.0\r\n";
$dari .= "Content-Transfer-Encoding: 8bit\r\n";
$dari .= "X-Mailer: PHP v.".phpversion();
mail($email,$subject,$pesan,$dari);

$hasil='Silakan klik link konfirmasi berlangganan yang telah Kami kirim ke email Anda. Link konfirmasi berlaku selama 5 jam dari sekarang.';
}
}
}
else
{
$hasil=''.$error.' <a href="'.$site['url'].'/posts/subscribe.xhtml">Kembali</a>';
}
}

$head_title='Berlangganan Posting Terbaru';
include 'main-inc/header.web.php';
echo '<div id="content"><div class="post-single"><h2>Berlangganan</h2><div style="float: left;"></div>';
if (!empty($hasil))
{
echo '<p>'.$hasil.'</p>';
}
else
{
echo '<p>Anda akan berlangganan Posting terbaru</p><p><form method="post" action="'.$site['url'].$_SERVER['REQUEST_URI'].'"><b>Email Anda</b><br/>';
if ($user_id)
echo '<input type="text" name="my_email" value="'.$user_email.'" />';
else
echo '<input type="text" name="my_email" value="" />';
echo '<br/><input type="submit" name="subscribe" value="Berlangganan"/>
</form></p>';
}
echo '<div style="float: left;"></div></div></div>';
include 'main-inc/footer.web.php';
break;


case 'new_comments':
if (isset($_POST['subscribe']))
{
$my_email=$_POST['my_email'];
if (mb_strlen($my_email) < 2 || mb_strlen($my_email) > 250)
$error='Panjang email maksimal 250 karakter';
if (!eregi("^[a-z0-9\._-]+@[a-z0-9\._-]+\.[a-z]{2,4}\$", $my_email))
$error='Alamat email tidak benar';if (empty($my_email))
$error='Silakan masukan alamat email';
if (empty($error))
{
$cek_email=mysql_query("select * from subscribe where email='".mysql_real_escape_string($my_email)."' and status='1'");
if (mysql_num_rows($cek_email) != 0)
{
$cek_sub=mysql_query("select * from subscribe where email='".mysql_real_escape_string($my_email)."' and sub='new_comments'");
if (mysql_num_rows($cek_sub) != 0)
{
$hasil='Sebelumnya Anda telah berlangganan komentar terbaru';
}
else
{
$tim=time();
$cod=''.$tim.rand(10000, 99999).'';
mysql_query("insert into subscribe set email='".mysql_real_escape_string($my_email)."', sub='new_comments', status='1', code='".$cod."', time='".$tim."'");
$hasil='Anda berhasil berlangganan komentar terbaru';
}
}
else
{

$cek_sub=mysql_query("select * from subscribe where email='".mysql_real_escape_string($my_email)."' and sub='new_comments'");
if (mysql_num_rows($cek_sub) != 0)
{
$res=mysql_fetch_array($cek_sub);
$adm=mysql_fetch_array(mysql_query("select * from user where admin='1' limit 1;"));

$email = $my_email;
$subject="Konfirmasi Berlangganan";
$pesan="Jika Anda telah mencoba berlangganan Komentar terbaru pada ".$site['name']." silakan konfirmasikan berlangganan dengan mengklik link berikut...\r\n\r\n".$site['url']."/subscribe/".$res['code']."\r\n\r\n";
$pesan .= "\r\n\r\n";
$pesan .= "\r\nTerima Kasih\r\n";
$pesan .= $site['name'];
$pesan .= "\r\n\r\n";
$pesan .= $site['url'];
$dari = "From: ".$site['name']." <".$adm['email'].">\r\n";
$dari .= "X-sender: ".$site['name']." <".$adm['email'].">\r\n";
$dari .= "Content-type:text/plain; charset=iso-8859-1\r\n";
$dari .= "MIME-Version: 1.0\r\n";
$dari .= "Content-Transfer-Encoding: 8bit\r\n";
$dari .= "X-Mailer: PHP v.".phpversion();
mail($email,$subject,$pesan,$dari);

$hasil='Silakan klik link konfirmasi berlangganan yang telah kami kirim ke email Anda. Link konfirmasi berlaku selama 5 jam dari sekarang.';
}
else
{
$tim=time();
$cod=''.$tim.rand(10000, 99999).'';
mysql_query("insert into subscribe set email='".mysql_real_escape_string($my_email)."', sub='new_comments', status='0', code='".$cod."', time='".$tim."'");

$adm=mysql_fetch_array(mysql_query("select * from user where admin='1' limit 1;"));

$email = $my_email;
$subject="Konfirmasi Berlangganan";
$pesan="Jika Anda telah mencoba berlangganan Komentar terbaru pada ".$site['name']." silakan konfirmasikan berlangganan dengan mengklik link berikut...\r\n\r\n".$site['url']."/subscribe/".$cod."\r\n\r\n";
$pesan .= "\r\n\r\n";
$pesan .= "\r\nTerima Kasih\r\n";
$pesan .= $site['name'];
$pesan .= "\r\n\r\n";
$pesan .= $site['url'];
$dari = "From: ".$site['name']." <".$adm['email'].">\r\n";$dari .= "Content-type:text/plain; charset=iso-8859-1\r\n";
$dari .= "MIME-Version: 1.0\r\n";
$dari .= "Content-Transfer-Encoding: 8bit\r\n";
$dari .= "X-Mailer: PHP v.".phpversion();
mail($email,$subject,$pesan,$dari);

$hasil='Silakan klik link konfirmasi berlangganan yang telah Kami kirim ke email Anda. Link konfirmasi berlaku selama 5 jam dari sekarang.';
}
}
}
else
{
$hasil=''.$error.' <a href="'.$site['url'].'/comments/subscribe.xhtml">Kembali</a>';
}
}



$head_title='Berlangganan Komentar Terbaru';
include 'main-inc/header.web.php';
echo '<div id="content"><div class="post-single"><h2>Berlangganan</h2><div style="float: left;"></div>';
if (!empty($hasil))
{
echo '<p>'.$hasil.'</p>';
}
else
{
echo '<p>Anda akan berlangganan Komentar terbaru</p><p><form method="post" action="'.$site['url'].$_SERVER['REQUEST_URI'].'"><b>Email Anda</b><br/>';
if ($user_id)
echo '<input type="text" name="my_email" value="'.$user_email.'" />';
else
echo '<input type="text" name="my_email" value="" />';
echo '<br/><input type="submit" name="subscribe" value="Berlangganan"/>
</form></p>';
}
echo '<div style="float: left;"></div></div></div>';
include 'main-inc/footer.web.php';
break;

default:
$sub=$_GET['sub'];
if (empty($sub))
$sub=$_POST['sub'];
$Req=mysql_query("select * from blog where link='".mysql_real_escape_string($sub)."' limit 1;");
if (mysql_num_rows($Req) != 0)
{
$blog=mysql_fetch_array($Req);

}
if (isset($_POST['subscribe']))
{
$my_email=$_POST['my_email'];
if (mb_strlen($my_email) < 2 || mb_strlen($my_email) > 250)
$error='Panjang email maksimal 250 karakter';
if (!eregi("^[a-z0-9\._-]+@[a-z0-9\._-]+\.[a-z]{2,4}\$", $my_email))
$error='Alamat email tidak benar';if (empty($my_email))
$error='Silakan masukan alamat email';
if (empty($error))
{
$cek_email=mysql_query("select * from subscribe where email='".mysql_real_escape_string($my_email)."' and status='1'");
if (mysql_num_rows($cek_email) != 0)
{
$cek_sub=mysql_query("select * from subscribe where email='".mysql_real_escape_string($my_email)."' and sub='".mysql_real_escape_string($sub)."'");
if (mysql_num_rows($cek_sub) != 0)
{
$hasil='Sebelumnya Anda telah berlangganan komentar <a href="'.$site['url'].'/'.$blog['link'].'.xhtml">'.htmlspecialchars($blog['title']).'</a>';
}
else
{
$tim=time();
$cod=''.$tim.rand(10000, 99999).'';
mysql_query("insert into subscribe set email='".mysql_real_escape_string($my_email)."', sub='".mysql_real_escape_string($sub)."', status='1', code='".$cod."', time='".$tim."'");
$hasil='Anda berhasil berlangganan komentar <a href="'.$site['url'].'/'.$blog['link'].'.xhtml">'.htmlspecialchars($blog['title']).'</a>';
}
}
else
{

$cek_sub=mysql_query("select * from subscribe where email='".mysql_real_escape_string($my_email)."' and sub='".mysql_real_escape_string($sub)."'");
if (mysql_num_rows($cek_sub) != 0)
{
$res=mysql_fetch_array($cek_sub);
$adm=mysql_fetch_array(mysql_query("select * from user where admin='1' limit 1;"));

$email = $my_email;
$subject="Konfirmasi Berlangganan";
$pesan="Jika Anda telah mencoba berlangganan Komentar ".$blog['title']." pada ".$site['name']." silakan konfirmasikan berlangganan dengan mengklik link berikut...\r\n\r\n".$site['url']."/subscribe/".$res['code']."\r\n\r\n";
$pesan .= "\r\n\r\n";
$pesan .= "\r\nTerima Kasih\r\n";
$pesan .= $site['name'];
$pesan .= "\r\n\r\n";
$pesan .= $site['url'];
$dari = "From: ".$site['name']." <".$adm['email'].">\r\n";
$dari .= "X-sender: ".$site['name']." <".$adm['email'].">\r\n";
$dari .= "Content-type:text/plain; charset=iso-8859-1\r\n";
$dari .= "MIME-Version: 1.0\r\n";
$dari .= "Content-Transfer-Encoding: 8bit\r\n";$dari .= "X-Mailer: PHP v.".phpversion();
mail($email,$subject,$pesan,$dari);

$hasil='Silakan klik link konfirmasi berlangganan yang telah kami kirim ke email Anda. Link konfirmasi berlaku selama 5 jam dari sekarang.';
}
else
{
$tim=time();
$cod=''.$tim.rand(10000, 99999).'';
mysql_query("insert into subscribe set email='".mysql_real_escape_string($my_email)."', sub='".mysql_real_escape_string($sub)."', status='0', code='".$cod."', time='".$tim."'");

$adm=mysql_fetch_array(mysql_query("select * from user where admin='1' limit 1;"));

$email = $my_email;
$subject="Konfirmasi Berlangganan";
$pesan="Jika Anda telah mencoba berlangganan ".$blog['title']." pada ".$site['name']." silakan konfirmasikan berlangganan dengan mengklik link berikut...\r\n\r\n".$site['url']."/subscribe/".$cod."\r\n\r\n";
$pesan .= "\r\n\r\n";
$pesan .= "\r\nTerima Kasih\r\n";
$pesan .= $site['name'];
$pesan .= "\r\n\r\n";
$pesan .= $site['url'];
$dari = "From: ".$site['name']." <".$adm['email'].">\r\n";$dari .= "Content-type:text/plain; charset=iso-8859-1\r\n";$dari .= "MIME-Version: 1.0\r\n";
$dari .= "Content-Transfer-Encoding: 8bit\r\n";
$dari .= "X-Mailer: PHP v.".phpversion();
mail($email,$subject,$pesan,$dari);

$hasil='Silakan klik link konfirmasi berlangganan yang telah Kami kirim ke email Anda. Link konfirmasi berlaku selama 5 jam dari sekarang.';
}
}
}
else
{
$hasil=''.$error.' <a href="'.$site['url'].'/'.htmlentities($sub).'/subscribe.xhtml">Kembali</a>';
}
}


$head_title='Berlangganan komentar: '.$blog['title'].'';
include 'main-inc/header.web.php';
echo '<div id="content"><div class="post-single"><h2>Berlangganan</h2><div style="float: left;"></div>';
if (!empty($hasil))
{
echo '<p>'.$hasil.'</p>';
}
else
{
echo '<p>';
$rek=mysql_query("select * from blog where link='".mysql_real_escape_string($sub)."' limit 1;");
if (mysql_num_rows($rek) == 0)
{
echo 'Tidak ada blog yang dipilih. Harap periksa url yang Anda masukan.';
}
else
{
echo 'Anda akan berlangganan komentar <a href="'.$site['url'].'/'.$blog['link'].'.xhtml">'.htmlspecialchars($blog['title']).'</a>';

echo '</p><p><form method="post" action="'.$site['url'].$_SERVER['REQUEST_URI'].'"><b>Email Anda</b><br/>';
if ($user_id)
echo '<input type="text" name="my_email" value="'.$user_email.'" />';
else
echo '<input type="text" name="my_email" value="" />';
echo '<input type="hidden" name="sub" value="'.htmlentities($sub).'" />';
echo '<br/><input type="submit" name="subscribe" value="Berlangganan"/>
</form>';
}
}
echo '</p><div style="float: left;"></div></div></div>';
include 'main-inc/footer.web.php';
}
?>