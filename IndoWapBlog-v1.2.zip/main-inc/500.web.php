<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');
$head_title='Kesalahan Internal Server';
include 'main-inc/header.web.php';
echo '<div id="content"><div class="post-single"><h2>Kesalahan Internal Server</h2><div style="float: left;"></div>
	<p>Maaf, terjadi kesalahan internal server!</p><div style="float: left;"></div></div></div>';
include 'main-inc/footer.web.php';

?>