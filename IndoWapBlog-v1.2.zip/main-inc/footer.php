<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

$cat_loc=$site['cat_loc'];
if ($cat_loc=="bottom")
{
$cat_loc="bottom";
echo category($cat_loc);
}
echo '<div id="navigation"><h2>Navigasi</h2><ol>';
if ($pagination=="on")
{
pagination($page,$max_view,$total,$link,$q);
}
if ($homepage != 'off')
echo '<li><a href="'.$site['url'].'">Beranda</a></li>';
$nav=mysql_query("select * from navigation order by id asc");
while ($navs=mysql_fetch_array($nav))
{
$sn='_SITE_NAME_';
$su='_SITE_URL_';
echo '<li>'.html_entity_decode(htmlentities(str_replace($sn,$site['name'],str_replace($su,$site['url'],$navs['code'])))).'</li>';
}
if ($user_id)
{
echo '<li><a href="'.$site['url'].'/dashboard.php">Dashboard</a></li>';
echo '<li><a href="'.$site['url'].'/login.php?iwb=logout">Keluar</a></li>';
}
else
{
echo '<li><a href="'.$site['url'].'/login.php">Masuk</a></li>';
}
if ((!$user_id) && ($site['allow_reg'] == 1))
echo '<li><a href="'.$site['url'].'/register.php">Pendaftaran</a></li>';
echo '<li class="link-top"><a accesskey="*" href="#top">Ke Atas</a></li>';
echo '</ol></div>';
if ($site['display_following'] == '1' && $disfoll != 'off' && mysql_num_rows(mysql_query("select url from following")) > 0)
{
echo '<div id="blogroll"><h2>Following</h2><ol>';
$rq=mysql_query("select title, url from following order by id desc limit 10;");
while($rs=mysql_fetch_array($rq))
{
echo '<li><a href="'.$rs['url'].'">'.htmlspecialchars($rs['title']).'</a></li>';
}
echo '</ol></div>';
}
echo '<div id="footer"><p>';

$t_day=date('d-m-Y', time());
$qr=mysql_query("select total from stats where time='$t_day'");
$Qr=mysql_fetch_array($qr);
$new_count = $Qr['total'] + 1;
if (mysql_num_rows($qr) == 0)
{
mysql_query("insert into stats set total='1', time='$t_day'");
}
else
{
mysql_query("update stats set total='$new_count' where time='$t_day'");
}

if ($site['display_count'] == 1)
{
$ol = time() - 300;

$user_ol=mysql_result(mysql_query("SELECT COUNT(*) FROM user WHERE lastdate > $ol"), 0);

$guest_ol=mysql_result(mysql_query("SELECT COUNT(*) FROM guest WHERE lastdate > $ol"), 0);
echo 'Online : <span style="background: #333333; padding: 2px; border: 2px dashed #dddddd; color: #ffffff;"><a href="'.$site['url'].'/online.php">'.$user_ol.'/'.$guest_ol.'</a></span><br/>';
$t_all=mysql_fetch_array(mysql_query("select sum(total) as total from stats"));

echo 'Total Pengunjung: <span style="background: #333333; padding: 2px; border: 2px dashed #dddddd; color: #ffffff;">'.$t_all['total'].'</span><br/>';
}
echo '&copy; '.date('Y', time()).' <a href="'.$site['url'].'">'.$site['name'].'</a>.<br /><small>Powered by <a href="http://indowapblog.com">IndoWapBlog.com</a></small</p></div></body></html>';
following_reader();
import_rss();
mysql_close($iwb_connect);
?>