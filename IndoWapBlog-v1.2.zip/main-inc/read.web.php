<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

$t=$_GET['t'];

$cek=mysql_query("select * from blog where link='" . mysql_real_escape_string($t) . "' and draft='0'");
if (mysql_num_rows($cek) == 0)
{
include 'main-inc/header.web.php';
echo '<div id="content"><div class="post-single"><h2>Blog tidak ditemukan</h2><div style="float: left;"></div>
	<p>Maaf, blog tidak ditemukan.</p></div></div>';
include 'main-inc/footer.web.php';
}
else
{
$blogs=mysql_fetch_array(mysql_query("select * from blog where link='" . mysql_real_escape_string($t) . "' and draft='0' limit 1;"));

$tot = $blogs['count'] + 1;
mysql_query("update blog set count='".$tot."' where id='".$blogs['id']."'");

$page=$_GET['page'];
$total=mysql_result(mysql_query("select count(*) as Num from comment where blog_id='".$blogs['id']."' and status='1'"),0);

$gp = ceil($total / $site['num_post_main']);

if (empty($page))
$page=$gp;
if ($page=='0')
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;

$head_description=$blogs['description'];
$head_title=$blogs['title'];
include 'main-inc/header.web.php';

echo '<div id="content"><div class="post-single"><h2>'.htmlspecialchars($blogs['title']).'</h2>';
$auth=mysql_fetch_array(mysql_query("select * from user where id='".$blogs['user_id']."'"));
echo '<p class="meta">oleh <a href="'.$site['url'].'/user.php?id='.$blogs['user_id'].'">'.htmlspecialchars($auth['name']).'</a> pada '.waktu($blogs['time']).'</p><div style="float: left;"></div>';
if ($blogs['private'] == 1)
{
 if ($user_id)
echo '<p>'.html_entity_decode(bbsm($blogs['description'])).'</p>';
else
echo '<p>Postingan ini hanya untuk Member <b>'.htmlspecialchars($site['name']).'</b>. Untuk melihat postingan ini silakan login atau register terlebih dahulu.</p>';
}

elseif ($blogs['private'] == 2)
{
 if ($is_author)
echo '<p>'.html_entity_decode(bbsm($blogs['description'])).'</p>';
else
echo '<p>Postingan ini hanya untuk Penulis (Author) <b>'.htmlspecialchars($site['name']).'</b>.</p>';
}
else
{
echo '<p>'.html_entity_decode(bbsm($blogs['description'])).'</p>';
}
echo '<br /><p class="share_button"><a href="http://www.facebook.com/sharer.php?u='.$site['url'].'/'.$blogs['link'].'.xhtml" rel="nofollow"><img src="'.$site['url'].'/files/fb_share.gif" alt="Share on Facebook" /></a><g:plusone count="false" href="'.$site['url'].'/'.$blogs['link'].'.xhtml"></g:plusone>
		<script type="text/javascript">
		  (function() {
		    var po = document.createElement("script"); po.type = "text/javascript"; po.async = true;
		    po.src = "https://apis.google.com/js/plusone.js";
		    var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(po, s);
		  })();
		</script></p>';
echo 'Kategori: ';
$exkt=explode(",",$blogs['category']);
$countexp=count($exkt);
for ($e=0;$e<$countexp;$e++)
{
$ktname=mysql_fetch_array(mysql_query("select * from category where id='".$exkt[$e]."'"));
echo '<a href="'.$site['url'].'/category/'.$ktname['link'].'/1.xhtml">'.htmlentities($ktname['name']).'</a>, ';
}
echo '</p>';        echo '<div style="clear:both"></div>
    </div>';
function show_comments()
{
global $blogs, $site, $user_id, $user_name, $user_site, $user_email, $t, $limit, $max_view;
echo '<div id="comment">
        <h2><a name="comment">Komentar</a> <small>(<a href="'.$site['url'].'/'.$blogs['link'].'/rss.xml">RSS</a> / <a href="'.$site['url'].'/'.$blogs['link'].'/subscribe.xhtml">E-Mail</a>)</small></h2>';
$total_comments=mysql_result(mysql_query("select count(*) as Num from comment where blog_id='".$blogs['id']."' and status='1'"),0);
if ($total_comments>0)
{
echo '<h3>'.$total_comments.' Respon untuk
&quot;'.htmlspecialchars($blogs['title']).'&quot;</h3>';
}else
{
echo '<h3>Belum ada komentar. Kenapa tidak menjadi yang pertama.</h3>';
}
if ($site['display_count'] == 1)
echo '<h3>Dilihat sebanyak &quot;'.$blogs['count'].'&quot; kali</h3>';
$comment=mysql_query("select * from comment where blog_id='".$blogs['id']."' and status='1' order by time asc limit $limit,$max_view");
while ($comments=mysql_fetch_array($comment))
{

echo '<div class="comment">
<h3><a href="'.htmlentities($comments['site']).'/" rel="nofollow">'.htmlspecialchars($comments['name']).'</a><small> ['.waktu($comments['time']).']</small></h3>
<p>'.bbsm($comments['text']).'</p>
</div>';
}


if ($blogs['allow_comment'] == '1')
{
echo '<h2><a name="new_comment">Komentar Baru</a></h2>';
$skrg='/'.$blogs['link'].'.xhtml?';
$Rep='';
$string=$_SERVER['REQUEST_URI'];
$string=str_replace($skrg,$Rep,$string);
if ($string == 'err_code')
$hasil='Kode keamanan yang kamu masukan tidak benar';
if ($string == 'err_msg')
$hasil='Silakan masukan komentar anda';
if ($string == 'err_mail')
$hasil='Silakan masukan email anda';
if ($string == 'err_invalid_email')
$hasil='Email yang anda masukan tidak benar';

if ($string == 'err_leng_email')
$hasil='Panjang email 2 sampai 32 karakter';
if ($string == 'err_name')
$hasil='Silakan masukan nama anda';
if ($string == 'ok')
$hasil='Komentar akan ditampilkan setelah disetujui administrator';
if ($string == 'success')
$hasil='Komentar berhasil ditambahkan';
if (!empty($hasil))
echo '<ol style="padding: 0px; margin: 0px; background: #dd9900;"><li>'.$hasil.'</li></ol>';
if ($user_id)
{
$form_title=$user_name;
$form_site=$user_site;
$form_email=$user_email;
}
else
{
$form_title=stripslashes($_SESSION['nama']);
$form_site=stripslashes($_SESSION['url']);
$form_email=stripslashes($_SESSION['email']);
}
echo '<form
id="comment_form"
action="'.$site['url'].'/comment.xhtml"
method="post">
<p>';
$redir=''.$site['url'].'/'.$blogs['link'].'.xhtml#new_comment';
if (!$user_id)
echo '[<a
href="'.$site['url'].'/login.php?redir='.base64_encode($redir).'" rel="nofollow">Masuk</a>]
<br/>';
echo 'Nama: <br/>
<input type="text"
name="title" value="'.$form_title.'"/><br/>Situs: <br/>
<input type="text"
name="url" value="'.$form_site.'"/>';
if ($site['comment_email'] == '1')
echo '<br/>Email: <br/>
<input type="text"
name="email" value="'.$form_email.'"/>';
echo '<br/>
Komentar:<br/>
(Kamu bisa menggunakan <a href="'.$site['url'].'/bbsm.php?iwb=bbcode">BBCode</a> dan <a href="'.$site['url'].'/bbsm.php?iwb=smiley">Smiley</a>.)<br/>
<textarea
name="body" rows="4"/></textarea>';
if ($site['comment_captcha'] == 1)
{
$_SESSION['captcha_code'] = rand(1000, 9999);
echo '<br />Kode keamanan:<br /><img src="'.$site['url'].'/captcha.php" alt=""/><br /><input type="text" name="code" value=""/>';
}
else
{}
echo '</p><p><input type="hidden"
name="t" value="'.$t.'"/><input
name="comment"
type="submit" id="comment"
value="Komentari"/></p></form>';
}else{
echo '<h2><a name="new_comment">Komentar ditutup!</a></h2>';
}
echo '</div>';
}

if ($blogs['private'] == 1 && $user_id)
{
show_comments();
$pagin='1';
}
elseif ($blogs['private'] == 1 && !$user_id)
{
echo '<div id="comment"><h2>Komentar</h2><p>Komentar disembunyikan.</p></div>';
}
elseif ($blogs['private'] == 2 && $is_author)
{
show_comments();
$pagin='1';
}
elseif ($blogs['private'] == 2 && !$is_author)
{
echo '<div id="comment"><h2>Komentar</h2><p>Komentar disembunyikan.</p></div>';
}
else
{
show_comments();
$pagin='1';
}

if (($pagin == 1) && ($total > 0))
{
$link=''.$site['url'].'/'.htmlentities($t).'/page/';
$q='.xhtml';
if(empty($page))
$page='1';
$pages=Ceil($total/$max_view);
if ($pages>1)
{
echo '<div id="pagination_links">Halaman:<br /><div id="pagination_links">';
for ($i = 1; $i <= $pages; $i++)
{
if ($page==$i)
{$num=' ['.$i.'] ';}else{ $num=' [<a href="'.$link.''.$i.''.$q.'">'.$i.'</a>] ';}
echo $num;}
echo '</div></div>';
}
}
echo '</div>';
include 'main-inc/footer.web.php';
}
?>