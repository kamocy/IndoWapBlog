<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

$head_title=isset($head_title) ? $head_title : $site['name'];
$head_description=isset($head_description) ? $head_description : $site['description'];$head_description=strip_tags($head_description);$head_description=substr($head_description,0,400);

echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="'.$site['url'].'/themes/'.$site['theme_web'].'.css" type="text/css" />
<title>'.htmlspecialchars($head_title).'';
if ($head_title != $site['name'])
echo ' | '.htmlspecialchars($site['name']).'';
echo '</title><link rel="alternate" media="handheld" href="'.$site['url'].'/" title="Mobile/PDA" /><meta name="description" content="'.htmlentities(strip_tags($head_description)).'" /><meta name="keywords" content="'.htmlentities($site['keywords']).'" />';
echo '<link rel="alternate" type="application/rss+xml" title="RSS '.htmlspecialchars($site['name']).'" href="'.$site['url'].'/rss.xml" />';

if (!empty($site['meta_google']))
echo '<meta name="google-site-verification" content="'.htmlentities($site['meta_google']).'" />';

echo '<link rel="icon" href="'.$site['url'].'/files/favicon.ico" type="image/x-icon" />
    <link rel="shortcut icon" href="'.$site['url'].'/files/favicon.ico" type="image/x-icon" />
<script type="text/javascript" src="'.$site['url'].'/image-resizer.js"></script></head>
<body onload="image_resizer(390);">
<div id="container">';
$ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
$ip_via_proxy=$_SERVER['REMOTE_ADDR'];
$user_agent=$_SERVER['HTTP_USER_AGENT'];
$ref=''.$site['url'].$_SERVER['REQUEST_URI'].'';
if (!empty($site['logo']))
{$headitem='<img src="'.$site['url'].'/files/'.$site['logo'].'" alt="'.htmlentities($site['name']).'"/>';
}else{$headitem=htmlentities($site['name']);}
echo '<div id="header"><div id="left"><h1><a href="'.$site['url'].'">'.$headitem.'</a></h1><h2>'.htmlspecialchars($site['description']).'</h2></div></div>';
echo '<div style="clear: both;"></div><div id="content-container">';
if ($user_id)
{
$sol = time() - 300;
if ($user_lastdate < $sol)
{
mysql_query("update user set lastdate='".time()."' where id='".$user_id."'");
}
mysql_query("UPDATE `user` SET `ip_proxy`='".mysql_real_escape_string($ip_via_proxy)."', `ip_browser`='".mysql_real_escape_string($ip)."', `user_agent`='".mysql_real_escape_string($user_agent)."', `ref`='".mysql_real_escape_string($ref)."', `place`='".$head_title."' WHERE `id`='".$user_id."'");
$user_blocked=mysql_fetch_array(mysql_query("select ban from user where id='".$user_id."'"));
if ($user_blocked['ban'] == '1')
{
echo '<div class="post"><h2 class="title">Pemblokiran Akun <small>['.waktu(time()).']</small></h2>';
echo '<p>Maaf, akun Anda dengan data dibawah ini:<br/><br/>ID : '.$user_id.'<br/>Username : '.$user_username.'<br/>Email : '.$user_email.'<br/><br/>saat ini akun tersebut telah diblokir untuk sementara waktu atau selamanya. Silakan keluar dari akun ini atau kembali berkunjung ke '.htmlspecialchars($site['name']).' setelah beberapa saat lagi!</p></div>';
include 'main-inc/footer.php';
exit;
}
else
{}
}
else
{
$session = md5($ip . $ip_via_proxy . $user_agent);
$req=mysql_query("SELECT * FROM `guest` WHERE `session_id`='".$session."'");
if (mysql_num_rows($req) != 0)
{
mysql_query("UPDATE `guest` SET `lastdate`='".time()."', `sestime`='".time()."', `ref`='".mysql_real_escape_string($ref)."', `place`='".$head_title."' WHERE `session_id`='".$session."'");
} else {
mysql_query("INSERT INTO `guest` SET `session_id`='".$session."', `ip_browser`='".mysql_real_escape_string($ip)."', `ip_proxy`='".mysql_real_escape_string($ip_via_proxy)."', `user_agent`='".mysql_real_escape_string($user_agent)."', `lastdate`='".time()."', `sestime`='".time()."', `ref`='".mysql_real_escape_string($ref)."', `place`='".$head_title."'");
}
$ip1=$_SERVER['HTTP_X_FORWARDED_FOR'];
$ip2=$_SERVER['REMOTE_ADDR'];
$ip_cek=mysql_query("select * from blocked where ip='".mysql_real_escape_string($ip1)."' or ip='".mysql_real_escape_string($ip2)."'");
if (mysql_num_rows($ip_cek) != 0)
{
$ip_blocked=mysql_fetch_array($ip_cek);
echo '<div class="post"><h2 class="title">Pemblokiran IP <small>['.waktu(time()).']</small></h2>';
echo '<p>Maaf, untuk sementara waktu IP yang Anda gunakan (<b>'.$ip_blocked['ip'].'</b>) dilarang untuk mengakses '.htmlspecialchars($site['name']).'!</p></div>'; 
include 'main-inc/footer.php';
exit;
}
else
{}
}
?>