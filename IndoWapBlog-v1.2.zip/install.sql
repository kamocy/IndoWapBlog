DROP TABLE IF EXISTS `blocked`;

CREATE TABLE `blocked` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(15) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




DROP TABLE IF EXISTS `blog`;

CREATE TABLE `blog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `title` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `description` text COLLATE latin1_general_ci NOT NULL,
  `link` varchar(102) COLLATE latin1_general_ci NOT NULL,
  `time` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `category` varchar(10) COLLATE latin1_general_ci NOT NULL DEFAULT '1',
  `tag` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `allow_comment` varchar(3) COLLATE latin1_general_ci NOT NULL,
  `draft` varchar(1) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
   `private` varchar(1) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `count` varchar(20) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `blog_id` text COLLATE latin1_general_ci NOT NULL,
  `link` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `category` VALUES("1","0","tak-berkategori","Tak Berkategori");



DROP TABLE IF EXISTS `chat`;

CREATE TABLE `chat` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `user_name` varchar(40) COLLATE latin1_general_ci NOT NULL,
  `text` text COLLATE latin1_general_ci NOT NULL,
  `time` varchar(10) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




DROP TABLE IF EXISTS `comment`;

CREATE TABLE `comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `blog_id` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `blog_user_id` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `site` varchar(132) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `text` text COLLATE latin1_general_ci NOT NULL,
  `status` varchar(1) COLLATE latin1_general_ci NOT NULL,
  `time` varchar(10) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;


DROP TABLE IF EXISTS `following`;

CREATE TABLE `following` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `title` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `subscribe` varchar(1) COLLATE latin1_general_ci NOT NULL default '1',
    `time` varchar(10) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




DROP TABLE IF EXISTS `following_post`;

CREATE TABLE `following_post` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `following_id` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `title` varchar(60) COLLATE latin1_general_ci NOT NULL,
  `description` text COLLATE latin1_general_ci NOT NULL,
  `link` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `read` varchar(1) COLLATE latin1_general_ci NOT NULL,
  `time` varchar(10) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;


DROP TABLE IF EXISTS `guest`;

CREATE TABLE `guest` (
  `session_id` char(32) NOT NULL DEFAULT '',
  `ip_browser` varchar(15) NOT NULL,
  `ip_proxy` varchar(15) NOT NULL,
  `user_agent` varchar(255) NOT NULL DEFAULT '',
  `lastdate` int(10) unsigned NOT NULL DEFAULT '0',
  `sestime` int(10) unsigned NOT NULL DEFAULT '0',
  `ref` varchar(255) NOT NULL DEFAULT '',
  `place` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`session_id`),
  KEY `lastdate` (`lastdate`),
  KEY `place` (`place`(10))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `guestbook`;

CREATE TABLE `guestbook` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `name` varchar(40) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `site` varchar(70) COLLATE latin1_general_ci NOT NULL,
  `text` text COLLATE latin1_general_ci NOT NULL,
  `status` varchar(1) COLLATE latin1_general_ci NOT NULL,
  `time` varchar(10) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;


DROP TABLE IF EXISTS `import_rss`;

CREATE TABLE `import_rss` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url_rss` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `url_post` varchar(400) COLLATE latin1_general_ci NOT NULL,
    `category` varchar(5) COLLATE latin1_general_ci NOT NULL default '1',
    `sumber` varchar(1) COLLATE latin1_general_ci NOT NULL default '0',
    `update_time` varchar(1) COLLATE latin1_general_ci NOT NULL,
  `time` varchar(10) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

DROP TABLE IF EXISTS `navigation`;

CREATE TABLE `navigation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `code` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `navigation` VALUES("1","<a href=\"http://feedvalidator.org/check.cgi?url=_SITE_URL_/rss.xml\"><img src=\"_SITE_URL_/files/valid-rss-rogers.png\" alt=\"[Valid RSS]\" title=\"Validate my RSS feed\" /></a>");
INSERT INTO `navigation` VALUES("2","Komentar: <a href=\"_SITE_URL_/comment/rss.xml\">[RSS]</a> | <a href=\"_SITE_URL_/comments/subscribe.xhtml\">[E-Mail]</a>");
INSERT INTO `navigation` VALUES("3","Posting: <a href=\"_SITE_URL_/rss.xml\">[RSS]</a> | <a href=\"_SITE_URL_/posts/subscribe.xhtml\">[E-Mail]</a>");
INSERT INTO `navigation` VALUES("4","<a href=\"_SITE_URL_/feedback.xhtml\">Feedback</a>");
INSERT INTO `navigation` VALUES("6","<a href=\"_SITE_URL_/guestbook.xhtml\">Buku Tamu</a>");
INSERT INTO `navigation` VALUES("7","<a href=\"_SITE_URL_/chat.php\">Chat Room</a>");
INSERT INTO `navigation` VALUES("8","<a href=\"_SITE_URL_/follow.xhtml\">Follow</a>");
INSERT INTO `navigation` VALUES("9","<a href=\"http://indowapblog.com\">Free Script IndoWapBlog</a>");



DROP TABLE IF EXISTS `pm`;

CREATE TABLE `pm` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `receiver_id` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `sender_id` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `name` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `text` text COLLATE latin1_general_ci NOT NULL,
  `read` varchar(1) COLLATE latin1_general_ci NOT NULL,
  `time` varchar(10) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




DROP TABLE IF EXISTS `replace_text`;

CREATE TABLE `replace_text` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `value` text COLLATE latin1_general_ci NOT NULL,
  `type` varchar(20) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;


DROP TABLE IF EXISTS `site`;

CREATE TABLE `site` (
  `name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `url` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `description` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `keywords` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `meta_google` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `theme` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `theme_web` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `logo` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `favicon` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `cat_loc` varchar(6) COLLATE latin1_general_ci NOT NULL DEFAULT 'top',
  `display_following` varchar(1) COLLATE latin1_general_ci NOT NULL,
  `display_count` varchar(1) COLLATE latin1_general_ci NOT NULL,
  `comment_email` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `comment_mod` varchar(1) COLLATE latin1_general_ci NOT NULL,
  `comment_captcha` varchar(1) COLLATE latin1_general_ci NOT NULL,
  `num_post_main` varchar(3) COLLATE latin1_general_ci NOT NULL DEFAULT '10',
  `desc_post_main` varchar(1) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `allow_reg` varchar(1) COLLATE latin1_general_ci NOT NULL,
  `reg_email` varchar(1) COLLATE latin1_general_ci NOT NULL,
  `reg_author` varchar(1) COLLATE latin1_general_ci NOT NULL,
  `gmt` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `version` varchar(10) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `site` VALUES("IndoWapBlog v1.2","http://indowapblog.com.nu","IndoWapBlog, Mobile Blog Community","indowapblog,open source,mobile blog","","default.wap","default.web","logo.gif","favicon.ico","top","1","1","1","0","1","10","0","1","0","0","+7","1.2");



DROP TABLE IF EXISTS `site_menu`;

CREATE TABLE `site_menu` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `link` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `user` varchar(1) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `author` varchar(1) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `admin` varchar(1) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;



INSERT INTO `site_menu` SET `link`='admin.php?iwb=import_rss', `name`='RSS Import', `admin`='1';

INSERT INTO `site_menu` SET `link`='admin.php?iwb=site_menu', `name`='Menu Situs', `admin`='1';

INSERT INTO `site_menu` SET `link`='admin.php?iwb=backup', `name`='MySQL Backup', `admin`='1';

DROP TABLE IF EXISTS `stats`;

CREATE TABLE `stats` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `total` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `time` varchar(10) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

DROP TABLE IF EXISTS `subscribe`;

CREATE TABLE `subscribe` (
`id` int(10) NOT NULL AUTO_INCREMENT,
`email` varchar(255) COLLATE latin1_general_ci NOT NULL,
`sub` varchar(62) COLLATE latin1_general_ci NOT NULL,
`status` varchar(1) COLLATE latin1_general_ci NOT NULL,
`code` varchar(15) COLLATE latin1_general_ci NOT NULL,
`time` varchar(10) COLLATE latin1_general_ci NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;


DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `gender` varchar(6) COLLATE latin1_general_ci NOT NULL,
  `birthday` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `address` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `about` text COLLATE latin1_general_ci NOT NULL,
  `site` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `admin` varchar(1) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `author` varchar(1) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `ban` varchar(1) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `confirm` varchar(38) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `ip_proxy` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `ip_browser` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `user_agent` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `lastdate` int(11) NOT NULL DEFAULT '0',
  `date_reg` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `ref` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `place` varchar(100) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




