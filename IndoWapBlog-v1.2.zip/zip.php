<?php

defined('_IWB_') or die('Kesalahan: Pembatasan Akses');

if (!$user_id)
relogin();

require_once('functions/installer.class.php');

$head_title='Ziper And Unziper';
include 'head.php';
echo '<div id="message"></div><div id="content">
<div id="main-content">';
if ($is_admin)
{
$action=isset($_GET['action']) ? trim($_GET['action']) : '';
$file=htmlentities($_GET['file']);
$dir=htmlentities(str_replace('%2F','/',$_GET['dir']));
switch ($action)
{
case 'unzip':
if($file!="")
{
$zip=new PclZip("$file");
if ($zip->extract(PCLZIP_OPT_PATH, "$dir/")!=0)
{
echo 'File <b>'.htmlentities($file).'</b> berhasil diekstrak ke folder <b>'.htmlentities($dir).'</b>';
}
else
{
echo 'Ekstrak <b>'.htmlentities($file).'</b> gagal!';
}
}
else
{
echo 'File ZIP tidak ditemukan!';
}
echo('<br /><br /><a href="admin.php?iwb=zip">Kembali</a>');
break;
case 'zip':
if($file!="" && $dir!="")
{
if (substr($dir,0,1) == '/')
$dir=substr($dir,1);
$zip=new PclZip("$dir/$file");
if ($zip->add("$dir", PCLZIP_OPT_REMOVE_PATH, "$dir")!=0)
{
$list = $zip->delete(PCLZIP_OPT_BY_NAME, $file);
echo '<br>Folder '.htmlentities($dir).' berhasil dibuat arsip '.htmlentities($file).'<br/><a href="'.$dir.'/'.$file.'">DOWNLOAD '.htmlentities($file).'</a>';
}
else
{
echo 'Gagal buat arsip. Cek file atau folder!';
}
}
else
{
echo 'File tidak ditemukan!';
}
echo('<br /><br /><a href="admin.php?iwb=zip">Kembali</a>');
break;
default:
echo '<form action="admin.php" method="get"><input type="hidden" name="iwb" value="zip"/><h4>Tindakan</h4><select class="iwb-select" name="action"><option value="unzip">Ekstrak ZIP</option><option value="zip">Buat ZIP</option></select><br><h4>File (Arsip ZIP)</h4><input class="iwb-text" type="text" name="file" size="30" value="" /><br><h4>Direktori/Folder</h4><input class="iwb-text" type="text" name="dir" size="30" value="" /><br><br><input class="iwb-button" type="submit" value="Submit" /></form>';
break;
}
}
else
{
forbidden();
}
echo '</div></div>';
include 'foot.php';
?>
