<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

define('_IWB_', 1);
$IWB_PLACE='dashboard';
include 'indowapblog.php';
if (!$user_id)
relogin();
$head_title='Dashboard';
include 'head.php';
echo '<style type="text/css">
#iphone-list
{
  margin: 2px;
  padding: 2px;
}
#iphone-list li
{
    list-style-type: none;
    margin: 2px;
    padding: 2px;
}
#iphone-list .heading
{
    list-style-type: none;
    margin: 2px;
    padding: 6px 5px 6px 5px;
    background-color: #333333;
    color: #FFFFFF;
    font-weight: bold;
}
#iphone-list li a
{
    display:block;
    padding: 6px 5px 6px 5px;
}
.iphone-list-border li a
{
    border-top: 2px solid #B4B4B4;
}
#iphone-list li a:hover
{
    background-color: #E1E1E1;
}
</style>';
echo '<div id="message">';
echo '</div>
<div id="content">
<div id="main-content">
<ul id="iphone-list">';

echo '<li class="heading">Menu</li><li><a href="'.$site['url'].'/">Blog</li><li><a href="'.$site['url'].'/chat.php">Chat Room</li><li><a href="guestbook.xhtml">Buku Tamu</li><li><a href="feedback.xhtml">Umpan Balik</li>';
$usMenu=mysql_query("select * from site_menu where user='1' order by name");
while ($uMenu=mysql_fetch_array($usMenu))
{
echo '<li><a href="'.$uMenu['link'].'">'.$uMenu['name'].'</a></li>';
}


if ($is_author)
{
echo '<li><a href="post.php?">Tulis Blog</a></li>';
echo '<li><a href="post.php?iwb=manage">Kelola Post</a></li>
    <li><a href="manage_comment.php?">Kelola Komentar</a></li>';
$autMenu=mysql_query("select * from site_menu where author='1' order by name");
while ($auMenu=mysql_fetch_array($autMenu))
{
echo '<li><a href="'.$auMenu['link'].'">'.$auMenu['name'].'</a></li>';
}
}

echo '<li><a href="user.php?iwb=list">List Pengguna</a></li>';
echo '</ul>            </div>
        </div>';
include 'foot.php';
?>