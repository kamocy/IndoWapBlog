<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

function hapus_array($item,$array)
{
$ex=explode(",",$array);

$co=count($ex);
for ($i=0;$i<$co;$i++)
{if ($ex[$i] == $item)
continue;
$ar[] = $ex[$i];
}
$array=implode(",",$ar);
return $array;
}
?>
