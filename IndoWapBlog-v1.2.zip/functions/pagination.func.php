<?phpfunction pagination($page,$max_view,$total,$link,$q)
{
$total_pages = $total;
 
if (empty($page) || ($page == 0)) $page = 1;
 $prev = $page - 1;       
 $next = $page + 1;      
 $lastpage = ceil($total_pages/$max_view);
 $lpm1 = $lastpage - 1;  if($lastpage > 1)
 { 
echo '<li class="link-page">Halaman: ';
  if ($page > 1) 
   echo ' [<a href="'.$link.$prev.$q.'">&laquo;</a>] ';
  else
   echo ''; 
  
  
  if ($lastpage < 7 + (3 * 2)) 
  { 
   for ($counter = 1; $counter <= $lastpage; $counter++)
   {
    if ($counter == $page)
     echo ' ['.$counter.'] ';
    else
     echo ' [<a href="'.$link.$counter.$q.'">'.$counter.'</a>] ';     
   }
  }
  elseif($lastpage > 5 + (3 * 2)) 
  {
  
   if($page < 1 + (3 * 2))  
   {
    for ($counter = 1; $counter < 4 + (3 * 2); $counter++)
    {
     if ($counter == $page)
      echo ' ['.$counter.'] ';
     else
      echo ' [<a href="'.$link.$counter.$q.'">'.$counter.'</a>] ';     
    }
    echo ' ... ';
    echo ' [<a href="'.$link.$lpm1.$q.'">'.$lpm1.'</a>] ';
    echo ' [<a href="'.$link.$lastpage.$q.'">'.$lastpage.'</a>] ';  
   }
  
   elseif($lastpage - (3 * 2) > $page && $page > (3 * 2))
   {
    echo ' [<a href="'.$link.'1'.$q.'">1</a>] ';
    echo ' [<a href="'.$link.'2'.$q.'">2</a>] ';
    echo ' ... ';
    for ($counter = $page - 3; $counter <= $page + 3; $counter++)
    {
     if ($counter == $page)
     echo ' ['.$counter.'] ';
     else
      echo ' [<a href="'.$link.$counter.$q.'">'.$counter.'</a>] ';     
    }
    echo ' ... ';
    echo ' [<a href="'.$link.$lpm1.$q.'">'.$lpm1.'</a>] ';
    echo ' [<a href="'.$link.$lastpage.$q.'">'.$lastpage.'</a>] ';  
   }
   //close to end; only hide early pages
   else
   {
    echo ' [<a href="'.$link.'1'.$q.'">1</a>] ';
    echo ' [<a href="'.$link.'2'.$q.'">2</a>] ';
    echo ' ... ';
    for ($counter = $lastpage - (2 + (3 * 2)); $counter <= $lastpage; $counter++)
    {
     if ($counter == $page)
     echo ' ['.$counter.'] ';
     else
      echo ' [<a href="'.$link.$counter.$q.'">'.$counter.'</a>] ';     
    }
   }
  }
  
 
  if (($page < $counter - 1) || ($page < $lastpage))
   echo ' [<a href="'.$link.$next.$q.'">&raquo;</a>] ';
  else
   echo '';
   }
echo '</li>';
}
?>
