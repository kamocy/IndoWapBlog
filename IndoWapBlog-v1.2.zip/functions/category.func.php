<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

/*Fungsi untuk menampilkan kategori top atau bottom*/
function category($cat_loc)
{
echo '<div id="category-'.$cat_loc.'"><h2>Kategori</h2><ol>';
$cat=mysql_query("select * from category order by name");
while ($cats=mysql_fetch_array($cat))
{
if (empty($cats['blog_id']))
{
$cat_count='0';
}
else
{
$bid=explode(",",$cats['blog_id']);
$cat_count=count($bid);
}
echo '<li><a href="'.$site['url'].'/category/'.permalink($cats['name']).'/1.xhtml">'.htmlspecialchars($cats['name']).'</a> ('.$cat_count.')</li>';
}
echo '</ol></div>';
}
?>
