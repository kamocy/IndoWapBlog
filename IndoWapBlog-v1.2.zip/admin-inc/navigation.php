<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

$action=isset($_GET['action']) ? trim($_GET['action']) : '';
switch ($action)
{
case 'delete':
if (!$user_id)
relogin();
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$nav_id=$_GET['nav_id'];
$cek=mysql_query("select * from navigation where id='".mysql_real_escape_string($nav_id)."'");
if (mysql_num_rows($cek) == 0)
{
include 'head.php';
page_not_found();
include 'foot.php';
exit;
}
if (isset($_GET['yes']))
{
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
else
{
mysql_query("delete from navigation where id='".mysql_real_escape_string($nav_id)."'");
header('location: admin.php?iwb=navigation');
}
}
$head_title='Hapus Item Navigasi';
include 'head.php';
echo '<div id="message"></div><div id="content">
<div id="main-content"><p>Anda yakin ingin menghapus item navigasi ini?<br/>[<a href="admin.php?iwb=navigation&amp;action=delete&amp;nav_id='.$nav_id.'&amp;yes">YA</a>] [<a href="admin.php?iwb=navigation">TIDAK</a>]</p></div></div>';
include 'foot.php';
break;

case 'edit':
if (!$user_id)
relogin();
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$nav_id=$_GET['nav_id'];
$cek=mysql_query("select * from navigation where id='".mysql_real_escape_string($nav_id)."'");
if (mysql_num_rows($cek) == 0)
{
include 'head.php';
page_not_found();
include 'foot.php';
exit;
}
if (isset($_POST['cancel']))
{
header('location: admin.php?iwb=navigation');
}
if (isset($_POST['save']))
{
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$item=$_POST['item_text'];
if (!empty($item))
{
mysql_query("update navigation set code='".mysql_real_escape_string($item)."' where id='".$nav_id."'");
header('location: admin.php?iwb=navigation');
}
else
{
$hsl='<ol id="error"><li>Teks tidak boleh kosong</li></ol>';
}
}
$nv=mysql_fetch_array($cek);
$head_title='Edit Item Navigasi';
include 'head.php';
echo '<div id="message">';
if (!empty($hsl))
echo $hsl;
echo '</div>
<div id="content">
<div id="main-content"><form method="post" action="admin.php?iwb=navigation&amp;action=edit&amp;nav_id='.$nav_id.'">
Kode HTML diperbolehkan.<br/> <textarea class="iwb-textarea" rows="3" cols="20" name="item_text">'.htmlentities($nv['code']).'</textarea>
<br/>
<div class="two-col-btn">
<input class="iwb-button" name="save" type="submit" value="Simpan"/>
<input class="iwb-button" name="cancel" type="submit" value="Batal"/>
</div>
</form>
</div></div>';
include 'foot.php';
break;

default:
if (!$user_id)
relogin();
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
if (isset($_POST['add']))
{
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$item=$_POST['item_text'];
if (!empty($item))
{
mysql_query("insert into navigation set code='".mysql_real_escape_string($item)."'");
$hsl='<ol id="success"><li>Item berhasil ditambahkan</li></ol>';
}
else
{
$hsl='<ol id="error"><li>Silakan masukan teks atau kode</li></ol>';
}
}
$head_title='Navigasi Menu';
include 'head.php';
echo '<div id="message">';
if (!empty($hsl))
echo $hsl;
echo '</div>
<div id="content">
<div id="main-content"><p>Gunakan halaman ini untuk menambahkan, menghapus atau mengubah item pada menu navigasi blog.</p>
<div id="action_bar"><a href="#add">Tambah Bru</a></div><big><b>Navigasi</b></big><br/><ol><li><font style="color: #999999;">Posting Baru</font></li><li><font style="color: #999999;">Posting Lama</font></li>';
$req=mysql_query("select * from navigation order by id asc");
while ($nv=mysql_fetch_array($req))
{
$sn='_SITE_NAME_';
$su='_SITE_URL_';
echo '<li>'.html_entity_decode(str_replace($sn,$site['name'],str_replace($su,$site['url'],$nv['code']))).'<br/><span class="action_links">[<a
class="edit" href="admin.php?iwb=navigation&amp;action=edit&amp;nav_id='.$nv['id'].'">Ubah</a>] [<a class="delete" href="admin.php?iwb=navigation&amp;action=delete&amp;nav_id='.$nv['id'].'">Hapus</a>]</span></li>';
}
echo '<li><font style="color: #999999;">[*] Ke Atas</font></li></ol><h3><a class="no-link" name="add">Tambah Item Baru</a></h3>Kode HTML diperbolehkan<br/>
<form method="post" action="admin.php?iwb=navigation">
<textarea class="iwb-textarea" name="item_text" rows="3"/></textarea><br/><input class="iwb-button"name="add" type="submit" value="Tambah"/></form></div></div>';
include 'foot.php';
}
?>