<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');
$action=isset($_GET['action']) ? trim($_GET['action']) : '';
switch ($action)
{
case 'edit':
if (!$user_id)
relogin();

if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$id=$_GET['id'];
$req=mysql_query("select url, title, subscribe from `following` where `id`='".mysql_real_escape_string($id)."'");
if (mysql_num_rows($req) == 0)
{
include 'head.php';
page_not_found();
include 'foot.php';
exit;
}
$fid=mysql_fetch_array($req);

if (isset($_POST['change']) && $is_admin)
{
$judul=$_POST['title'];
$sub_notify=$_POST['sub_notify'];
if (empty($judul))
{
$err='<ol id="error"><li>Silakan masukan judul</li></ol>';
}
else
{
mysql_query("update `following` set `title`='".mysql_real_escape_string($judul)."', subscribe='".mysql_real_escape_string($sub_notify)."' where `id`='".$id."'");
header('location: admin.php?iwb=following');
}
}
$head_title='Edit Following';
include 'head.php';
echo '<div id="message">';
if (!empty($err))
echo $err;
echo '</div>';
echo '<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="admin.php?iwb=following">Following</a> | <a href="admin.php?iwb=following&amp;action=updates">Posting Terbaru</a> | <a href="admin.php?iwb=following&amp;action=follow">Tambah Baru</a></div>';
echo '<form method="post" action="admin.php?iwb=following&amp;action=edit&amp;id='.$id.'">
<h4>URL Blog</h4><strong>'.$fid['url'].'</strong><br/><h4>Judul Blog</h4><input class="iwb-text" name="title" type="text" value="'.htmlentities($fid['title']).'" size="30"/><br/><h4>Berlangganan Pemberitahuan</h4><input type="radio" name="sub_notify" value="1"';
if ($fid['subscribe'] == 1)
echo ' checked';
echo '/>Ya<br/><input type="radio" name="sub_notify" value="0"';
if ($fid['subscribe'] == 0)
echo ' checked';
echo '/>Tidak<br/><p><input class="iwb-button" name="change" type="submit" value="Simpan"/></p></form>';

echo '</div></div>';
include 'foot.php';
break;

case 'unread_all':
if (!$user_id)
relogin();

if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
else
{
mysql_query("update `following_post` set `read`='0' where `read`='1'");
header('location: admin.php?iwb=following&action=read');
}
break;
case 'read':

if (!$user_id)
relogin();

if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
if (isset($_GET['more']))
{
$more=$_GET['more'];
$req=mysql_query("select link from `following_post` where `id`='".mysql_real_escape_string($more)."'");
if (mysql_num_rows($req) == 0)
{
header('location admin.php?iwb=following');
}
else
{
$res=mysql_fetch_array($req);
mysql_query("update `following_post` set `read`='0' where id='".mysql_real_escape_string($more)."'");
header("location: {$res['link']}");
}
}
else
{
$page=$_GET['page'];
if ($page=='0')
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;

$head_title='Posting Belum Dibaca';
include 'head.php';
echo '<div id="message">';
echo '</div>';
echo '<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="admin.php?iwb=following">Following</a> | <a href="admin.php?iwb=following&amp;action=updates">Posting Terbaru</a> | <a href="admin.php?iwb=following&amp;action=follow">Tambah Baru</a></div>';

echo '<ol>';
$total=mysql_result(mysql_query("select count(*) as num from `following_post` where `read`='1'"), 0);
if ($total == 0)
{
echo '<li>Belum ada satu pun postingan blog yang belum dibaca</li>';
}
else
{
$req=mysql_query("select * from `following_post` where `read`='1' order by time desc limit $limit,$max_view");
while ($res=mysql_fetch_array($req))
{
$fid=mysql_fetch_array(mysql_query("select * from following where id='".$res['following_id']."'"));
echo $i % 2 ? '<li class="row1">' : '<li class="row0">';
echo '<a href="admin.php?iwb=following&amp;action=read&amp;more='.$res['id'].'">'.htmlspecialchars($res['title']).' | '.htmlspecialchars($fid['title']).'</a> <small>('.time_ago($res['time']).')</small>';
++$i;
echo '</li>';

}
}
echo '</ol>';
if ($total > 0)
echo '<p><form method="get" action="admin.php"><input type="hidden" name="iwb" value="following"/><input type="hidden" name="action" value="unread_all"/><input class="iwb-button" type="submit" value="Tandai Sudah Dibaca"/></form></p>';
echo '</div>';
$link='admin.php?iwb=following&amp;action=read&amp;page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
echo '</div>';
include 'foot.php';
}
break;

case 'unfollow':
if (!$user_id)
relogin();

if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$id=$_GET['id'];
$cek=mysql_query("select * from following where id='".mysql_real_escape_string($id)."'");
if (mysql_num_rows($cek) == 0)
header('location: admin.php?iwb=following');
if (isset($_GET['yes']))
{
if (!$user_id)
relogin();

if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
else
{
mysql_query("delete from following where id='".$id."'");
mysql_query("delete from following_post where following_id='".$id."'");
header('location: admin.php?iwb=following');
}
}

$res=mysql_fetch_array($cek);

$head_title='Berhenti Mengikuti '.$res['title'].'';
include 'head.php';
echo '<div id="message">';
echo '</div>';
echo '<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="admin.php?iwb=following">Following</a> | <a href="admin.php?iwb=following&amp;action=updates">Posting Terbaru</a> | <a href="admin.php?iwb=following&amp;action=follow">Tambah Baru</a></div>';
echo '<p>Anda yakin akan berhenti mengikuti <a href="'.$res['url'].'">'.htmlentities($res['title']).'</a>?<br/>[<a href="admin.php?iwb=following&amp;action=unfollow&amp;id='.$id.'&amp;yes">Ya</a>] [<a href="admin.php?iwb=following">Tidak</a>]</p>';
echo '</div></div>';
include 'foot.php';
break;

case 'follow':
if (!$user_id)
relogin();

if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}

if (isset($_GET['url']))
{
if (!$user_id)
relogin();

if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$title=$_GET['title'];
$sub_notify=$_GET['sub_notify'];
if (empty($sub_notify))
$sub_notify='1';
$url=$_GET['url'];
$url=str_replace('http://','',$url);
if (empty($url))
$error='Silakan masukan URL Blog yang akan Anda ikuti';
else
$url='http://'.$url.'';
$url=parse_url($url);
$url=$url['host'];
if (empty($title))
$title=strtoupper($url);
$url='http://'.$url.'';
$url=strtolower($url);
$req=mysql_query("select * from following where url='".mysql_real_escape_string($url)."'");
if (mysql_num_rows($req) != 0)
$error=''.$url.' sebelumnya sudah ada pada daftar following Anda';
$rssck=''.$url.'/rss.xml';
if (!simplexml_load_file($rssck))
$error='GAGAL.. Pastikan URL adalah blog IndoWapBlog (IWB) atau MyWapBlog (MWB) dan minimal memiliki 1 posting.';
if (empty($error))
{
mysql_query("insert into following set url='".mysql_real_escape_string($url)."', title='".mysql_real_escape_string($title)."', subscribe='".mysql_real_escape_string($sub_notify)."', time='".time()."'");
$fid=mysql_insert_id();
$hasil='<ol id="success"><li><a href="admin.php?iwb=following&amp;action=edit&amp;id='.$fid.'">'.htmlspecialchars($title).'</a> Berhasil ditambahkan ke daftar Following Anda.</li></ol>';
}
else
{
$hasil='<ol id="error"><li>'.$error.'</li></ol>';
}
}
$head_title='Follow';
include 'head.php';
echo '<div id="message">';
if (!empty($hasil))
echo $hasil;
echo '</div>';
echo '<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="admin.php?iwb=following">Following</a> | <a href="admin.php?iwb=following&amp;action=updates">Posting Terbaru</a> | Tambah Baru</div>';
echo '<form method="get" action="admin.php">
<input type="hidden" name="iwb" value="following"/>
<input type="hidden" name="action" value="follow"/><h4>URL Blog</h4>
<br/><input class="iwb-text" name="url" type="text" value="http://" size="30"/><br/><span>URL Blog IWB atau MWB<h4>Judul Blog</h4><input class="iwb-text" name="title" type="text" value="" size="30"/><br/><span>Judul Blog yang diikuti (opsional)</span><br/><h4>Berlangganan Pemberitahuan</h4><input type="radio" name="sub_notify" value="1" checked/>Ya<br/><input type="radio" name="sub_notify" value="0"/>Tidak<br/>
<p><input class="iwb-button" type="submit" value="Ikuti"/></p></form>';
echo '</div></div>';
include 'foot.php';
break;

case 'updates':
$sid=$_GET['id'];
if (!$user_id)
relogin();

if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$page=$_GET['page'];
if ($page=='0')
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;
$head_title='Posting Terbaru';
include 'head.php';
echo '<div id="message">';
echo '</div>';
echo '<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="admin.php?iwb=following">Following</a> | <a href="admin.php?iwb=following&amp;action=updates">Posting Terbaru</a> | <a href="admin.php?iwb=following&amp;action=follow">Tambah Baru</a></div>';
echo '<ol>';
if (isset($_GET['id']))
{
$total=mysql_result(mysql_query("select count(*) as num from following_post where following_id='".mysql_real_escape_string($sid)."'"), 0);
$link='admin.php?iwb=following&amp;action=updates&amp;id='.htmlentities($sid).'&amp;page=';
}
else
{
$total=mysql_result(mysql_query("select count(*) as num from following_post"), 0);
$link='admin.php?iwb=following&amp;action=updates&amp;page=';
}
if ($total == 0)
{
echo '<li>Belum ada satu pun postingan blog</li>';
}
else
{
if (isset($_GET['id']))
{
$req=mysql_query("select * from following_post where following_id='".mysql_real_escape_string($sid)."' order by time desc limit $limit,$max_view");
}
else
{
$req=mysql_query("select * from following_post order by time desc limit $limit,$max_view");
}
while ($res=mysql_fetch_array($req))
{
$fid=mysql_fetch_array(mysql_query("select * from following where id='".$res['following_id']."'"));
echo $i % 2 ? '<li class="row1">' : '<li class="row0">';
echo '<a href="'.$res['link'].'">'.htmlspecialchars($res['title']).' | '.htmlspecialchars($fid['title']).'</a> <small>('.time_ago($res['time']).')</small>';
++$i;
echo '</li>';
}
}

echo '</ol></div>';
$q='';
pagination($page,$max_view,$total,$link,$q);
echo '</div>';
include 'foot.php';
break;

default:
if (!$user_id)
relogin();

if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$page=$_GET['page'];
if ($page=='0')
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;


$total=mysql_result(mysql_query("select count(*) as num from following"), 0);

$head_title='Following';
include 'head.php';
echo '<div id="message">';
echo '</div>';
echo '<div id="content">
<div id="main-content">';
echo '<div id="show_bar">Following | <a href="admin.php?iwb=following&amp;action=updates">Posting Terbaru</a> | <a href="admin.php?iwb=following&amp;action=follow">Tambah Baru</a></div>';
echo '<ol>';

if ($total == 0)
{
echo '<li>Belum ada satu pun blog yang Anda ikuti</li>';
}
else
{
$req=mysql_query("select * from following order by time desc limit $limit,$max_view");
while ($res=mysql_fetch_array($req))
{
echo $i % 2 ? '<li class="row1">' : '<li class="row0">';
echo '<a href="'.$res['url'].'/">';
if (!empty($res['title']))
echo htmlspecialchars($res['title']);
else
echo htmlentities($res['url']);
echo '</a> Mengikuti sejak '.waktu($res['time']).'<br/><span class="action_links">[<a href="admin.php?iwb=following&amp;action=edit&amp;id='.$res['id'].'">Edit</a>] [<a href="admin.php?iwb=following&amp;action=updates&amp;id='.$res['id'].'">Lihat update</a>] [<a class="delete" href="admin.php?iwb=following&amp;action=unfollow&amp;id='.$res['id'].'">Berhenti mengikuti</a>]</span>';
++$i;
echo '</li>';
}
}
echo '</ol></div>';
$link='admin.php?iwb=following&amp;page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
echo '</div>';
include 'foot.php';
}
?>