<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

$nama=$_POST['blog_name'];
$url=strtolower($_POST['blog_url']);
$deskripsi=$_POST['blog_description'];
$key=strtolower($_POST['blog_keywords']);
$google=$_POST['blog_meta_google'];
$tema=$_POST['blog_theme'];
$tema_web=$_POST['blog_theme_web'];
$catloc=$_POST['blog_cat_loc'];
$display_following=$_POST['blog_display_following'];
$discount=$_POST['blog_display_count'];
$logo=$_POST['blog_logo'];
$ico=$_POST['blog_favicon'];
$comment_email=$_POST['blog_comment_email'];
$comment_mod=$_POST['blog_comment_mod'];
$comment_captcha=$_POST['blog_comment_captcha'];
$desc=$_POST['blog_desc_post_main'];
$num_post_main=$_POST['blog_num_post_main'];
$allow_reg=$_POST['blog_allow_reg'];
$reg_email=$_POST['blog_reg_email'];
$author=$_POST['blog_reg_author'];
$gmt=$_POST['blog_gmt'];

if (!$user_id)
relogin();
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
if (isset($_POST['save']))
{
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}mysql_query("update site set name='".mysql_real_escape_string($nama)."', url='".mysql_real_escape_string($url)."', description='".mysql_real_escape_string($deskripsi)."', keywords='".mysql_real_escape_string($key)."', meta_google='".mysql_real_escape_string($google)."', theme='".mysql_real_escape_string($tema)."', theme_web='".mysql_real_escape_string($tema_web)."', cat_loc='".mysql_real_escape_string($catloc)."', display_following='".mysql_real_escape_string($display_following)."', display_count='".mysql_real_escape_string($discount)."', logo='".mysql_real_escape_string($logo)."', comment_email='".mysql_real_escape_string($comment_email)."', comment_mod='".mysql_real_escape_string($comment_mod)."', comment_captcha='".mysql_real_escape_string($comment_captcha)."', desc_post_main='".mysql_real_escape_string($desc)."', num_post_main='".mysql_real_escape_string($num_post_main)."', allow_reg='".mysql_real_escape_string($allow_reg)."', reg_email='".mysql_real_escape_string($reg_email)."', reg_author='".mysql_real_escape_string($author)."', gmt='".mysql_real_escape_string($gmt)."'") or die(mysql_error());
$hsl='<ol id="success"><li>Pengaturan disimpan</li></ol>';
}
$head_title='Pengaturan Blog';
include 'head.php';
echo '<div id="message">';
if (!empty($hsl))
echo $hsl;
echo '</div><div id="content">
<div id="main-content"><form method="post" action="admin.php?iwb=settings">
<h4>Nama</h4>
<input class="iwb-text" name="blog_name" type="text" value="'.htmlspecialchars($site['name']).'" maxlength="49" size="30"/><br/><span>Judul blog</span>
<h4>URL</h4>
<input class="iwb-text" name="blog_url" type="text" value="'.htmlspecialchars($site['url']).'" maxlength="49" size="30"/><br/><span>Url blog tanpa garis miring di akhir</span>
<br /><h4>Deskripsi</h4>
<input class="iwb-text" name="blog_description" type="text" value="'.htmlentities($site['description']).'" maxlength="300" size="30"/><br/><span>Deskripsi blog</span>
<h4>Kata kunci</h4>
<input class="iwb-text" name="blog_keywords" type="text" value="'.htmlentities($site['keywords']).'" maxlength="300" size="30"/><br/><span>Keywords pencarian. Pisahkan dengan koma.</span>
<br/><h4>Meta Google</h4>
<input class="iwb-text" name="blog_meta_google" type="text" value="'.htmlentities($site['meta_google']).'" maxlength="300" size="30"/><br/><span>Verifikasi <a href="https://www.google.com/webmasters/verification/verification?hl=en&siteUrl='.$site['url'].'/&continue=https://www.google.com/webmasters/tools/dashboard?hl%3Den%26siteUrl%3D'.$site['url'].'/">Meta tag Google</a></span><br/><h4>Tema WAP</h4>

<select class="iwb-select" name="blog_theme">';
$tem = glob('themes/*.wap.css');
foreach ($tem as $tems)
{
$tems = basename($tems);
$tems = str_replace('.css', '', $tems);
echo '<option' . ($site['theme'] == $tems ? ' selected="selected">' : '>') . $tems . '</option>';
}
echo '</select><br/><span>Tema blog WAP Version</span>
<br /><h4>Tema WEB</h4>
<select class="iwb-select" name="blog_theme_web">';
$tem = glob('themes/*web.css');
foreach ($tem as $tems)
{
$tems = basename($tems);
$tems = str_replace('.css', '', $tems);
echo '<option' . ($site['theme_web'] == $tems ? ' selected="selected">' : '>') . $tems . '</option>';
}
echo '</select><br/><span>Tema blog WEB Version</span>
<br />

<h4>Lokasi Kategori</h4>
    <select class="iwb-select" name="blog_cat_loc">';
if ($site['cat_loc'] == 'top')
echo '<option value="top">Atas</option><option value="bottom">Bawah</option>';
else
echo '<option value="bottom">Bawah</option><option value="top">Atas</option>';
    echo '</select><br/><span>Lokasi kategori</span><br /><h4>Tampilkan Konter</h4>
    <select class="iwb-select" name="blog_display_count">';
if ($site['display_count'] == '1')
echo '<option value="1">Ya</option><option value="0">Tidak</option>';
else
echo '<option value="0">Tidak</option><option value="1">Ya</option>';
echo '</select><br/><span>Tampilkan total hits pengunjung</span><br/><h4>Tampilkan Following</h4>
    <select class="iwb-select" name="blog_display_following">';
if ($site['display_following'] == '1')
echo '<option value="1">Ya</option><option value="0">Tidak</option>';
else
echo '<option value="0">Tidak</option><option value="1">Ya</option>';
echo '</select><br/><span>Tampilkan blog yang Anda ikuti (following).</span><br/><h4>Logo (<a href="file.php">Upload</a>)</h4>
        <select class="iwb-select" name="blog_logo">';
$fil = glob('files/*');
foreach ($fil as $fils)
{
$fils = str_replace('files/', '', $fils);
echo '<option' . ($site['logo'] == $fils ? ' selected="selected">' : '>') . $fils . '</option>';
}
echo '<option value="">Tanpa Logo</option></select><br/><span>Logo blog</span>
<br /><h4>Moderasi Komentar</h4><select class="iwb-select" name="blog_comment_mod">';
if ($site['comment_mod'] == 1)
echo '<option value="1">Ya</option><option value="0">Tidak</option>';
else
echo '<option value="0">Tidak</option><option value="1">Ya</option>';
echo '</select><br/><span>Moderasi komentar baru</span><br />';
echo '<h4>Captcha Komentar</h4><select class="iwb-select" name="blog_comment_captcha">';
if ($site['comment_captcha'] == 1)
echo '<option value="1">Ya</option><option value="0">Tidak</option>';
else
echo '<option value="0">Tidak</option><option value="1">Ya</option>';
echo '</select><br/><span>Menampilkan captcha pada form komentar</span><br />';
echo '<h4>Komentar Email</h4><select class="iwb-select" name="blog_comment_email">';
if ($site['comment_email'] == 1)
echo '<option value="1">Ya</option><option value="0">Tidak</option>';
else
echo '<option value="0">Tidak</option><option value="1">Ya</option>';
echo '</select><br/><span>Gunakan email pada form komentar</span><br />';
echo '<h4>Deskripsi Halaman Utama</h4><select class="iwb-select" name="blog_desc_post_main">';
if ($site['desc_post_main'] == 1)
echo '<option value="1">Penuh</option><option value="0">Singkat</option>';
else
echo '<option value="0">Singkat</option><option value="1">Penuh</option>';
echo '</select><br/><span><br/>Deskripsi/teks posting pada halaman awal</span><br /><h4>Jumlah Post Halaman Awal</h4>
<input class="iwb-text" name="blog_num_post_main" type="text" value="'.htmlentities($site['num_post_main']).'" maxlength="2" size="10"/><br/><span>Maksimal posting pada halaman awal.</span>
<br/>';
echo '<h4>Ijinkan pendaftaran</h4><select class="iwb-select" name="blog_allow_reg">';
if ($site['allow_reg'] == 1)
echo '<option value="1">Ya</option><option value="0">Tidak</option>';
else
echo '<option value="0">Tidak</option><option value="1">Ya</option>';
echo '</select><br/><span>Pendaftaran user baru</span><br />';
echo '<h4>Email konfirmasi pendaftaran</h4><select class="iwb-select" name="blog_reg_email">';
if ($site['reg_email'] == 1)
echo '<option value="1">Ya</option><option value="0">Tidak</option>';
else
echo '<option value="0">Tidak</option><option value="1">Ya</option>';
echo '</select><br/><span>Pendaftaran dengan email konfirmasi</span><br />';
echo '<h4>Ijinkan pengguna baru menulis blog</h4><select class="iwb-select" name="blog_reg_author">';
if ($site['reg_author'] == 1)
echo '<option value="1">Ya</option><option value="0">Tidak</option>';
else
echo '<option value="0">Tidak</option><option value="1">Ya</option>';
echo '</select><br/><span>Mengijinkan pengguna baru untuk menulis blog</span><br />';
echo '<h4>Zona Waktu</h4><select class="iwb-select" name="blog_gmt">';
echo '<option value="-12">GMT -12</option><option value="-11">GMT -11</option><option value="-10">GMT -10</option><option value="-9">GMT -9</option><option value="-8">GMT -8</option><option value="-7">GMT -7</option><option value="-6">GMT -6</option><option value="-5">GMT -5</option><option value="-4">GMT -4</option><option value="-3">GMT -3</option><option value="-2">GMT -2</option><option value="-1">GMT -1</option><option value="0">GMT 0</option><option value="+1">GMT +1</option><option value="+2">GMT +2</option><option value="+3">GMT +3</option><option value="+4">GMT +4</option><option value="+5">GMT +5</option><option value="+6">GMT +6</option><option value="+7">GMT +7</option><option value="+8">GMT +8</option><option value="+9">GMT +9</option><option value="+10">GMT +10</option><option value="+11">GMT +11</option><option value="+12">GMT +12</option>';
echo '</select><br/><span>Zona waktu lokal</span><br/><input class="iwb-button" name="save" type="submit" value="Simpan"/>
</form>            </div>
        </div>';
include 'foot.php';
?>