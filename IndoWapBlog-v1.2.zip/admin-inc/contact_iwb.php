<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

if (!$user_id)
relogin();
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
if (isset($_POST['contact_iwb']))
{
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$perihal=$_POST['perihal'];
$msg=$_POST['feedback'];
if (empty($perihal))
$err='Silakan pilih perihal';
if (empty($msg))
$err='Silakan isi pesan';
if (empty($err))
{
if ($perihal == 'fitur')
$subjek='Permintaan Fitur - IWB';
if ($perihal == 'tanggapan')
$subjek='Tanggapan - IWB';
if ($perihal == 'lainnya')
$subjek='Lainnya - IWB';
if ($perihal == 'error')
$subjek='Laporan Error - IWB';
if ($perihal == 'bantuan')
$subjek='Bantuan - IWB';

$adm=mysql_fetch_array(mysql_query("select * from user where admin='1' limit 1;"));

//*Kirim Pesan Ke Author IndoWapBlog (Achunk JealousMan)*//
$email = base64_decode('YWNodW5rMTdAZ21haWwuY29t');
$subject = $subjek;
$pesan="IWB Contact Support\r\n\r\n";
$pesan .= $msg;
$pesan .= "\r\n\r\n";
$pesan .= "Pengirim: ".$user_name."";
$pesan .= "\r\n\r\n";
$pesan .= "Situs: ".$site['url']."";
$pesan .= "\r\n\r\n";
$pesan .= "\r\n\r\nEmail: ".$user_email."\r\n\r\n";
$pesan .= "UA: ".$_SERVER['HTTP_USER_AGENT']."\r\n\r\n";
$pesan .= $site['name'];
$pesan .= "\r\n\r\n";
$pesan .= $site['url'];
$dari = "From: ".$site['name']." <".$adm['email'].">\r\n";
$dari .= "X-sender: ".$site['name']." <".$adm['email'].">\r\n";
$dari .= "Content-type:text/plain; charset=iso-8859-1\r\n";
$dari .= "MIME-Version: 1.0\r\n";
$dari .= "Content-Transfer-Encoding: 8bit\r\n";
$dari .= "X-Mailer: PHP v.".phpversion();
mail($email,$subject,$pesan,$dari);
header('location: admin.php');
}
else
{
$hsl='<ol id="error"><li>'.$err.'</li></ol>';
}

}
$head_title='Hubungi IndoWapBlog';
include 'head.php';
echo '<div id="message">';
if (!empty($hsl))
echo $hsl;
echo '</div>
<div id="content">
<div id="main-content">
<form action="admin.php?iwb=contact_iwb" method="post">
Perihal:<br/>
<select class="iwb-select" name="perihal">
<option value="">--Pilih--</option>
<option value="fitur">Permintaan Fitur</option>
<option value="error">Laporan Error</option>
<option value="bantuan">Bantuan</option><option value="tanggapan">Tanggapan</option>
<option value="lainnya">Lainnya</option></select><br/>
Pesan:<br/>
<textarea class="iwb-textarea" rows="5" cols="30" name="feedback"/></textarea><br/>
<input class="iwb-button" type="submit" name="contact_iwb" value="Kirim"/>
</form>            </div>
        </div>';
include 'foot.php';
?>