<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');
$action=isset($_GET['action']) ? trim($_GET['action']) : '';
switch ($action)
{
case 'install':
if (!$user_id)
relogin();

if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$name=base64_decode($_GET['name']);
$location=base64_decode($_GET['location']);
$modul=base64_decode($_GET['modul']);
$sql=base64_decode($_GET['sql']);
if (empty($location) || empty($modul) || isset($_POST['no']))
{
header('location: admin.php?iwb=iwb_market');
}

$head_title='Install: '.$name.'';
include 'head.php';
echo '<div id="message">';
echo '</div>';
echo '<div id="content">
<div id="main-content">';
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
if (isset($_POST['yes']) && $is_admin)
{
if (!empty($sql))
{
copy($sql,$location.sql);
chmod($location.sql, 0666);
$handle = fopen($location.sql, r);
$contents = fread($handle, filesize($location.sql));
fclose($handle);
$sep=';';
$contents=preg_replace("~(--|##)[^\r]*\r~","\r",$contents);
$contents=explode($sep,$contents);
foreach($contents as $coo) {
if(!empty($coo)) {
mysql_query($coo);
}
}
unlink($location.sql);
}
$unziper_file='iwb_file_package.zip';
if (copy($modul,$unziper_file))
{
require_once('functions/installer.class.php');
$dir='/';
$zip=new PclZip("$unziper_file");
if ($zip->extract(PCLZIP_OPT_PATH, "$dir/")!=0)
{
echo 'Installasi <b>'.htmlentities($name).'</b> berhasil<br>';
}
else
{
echo 'Installasi <b>'.htmlentities($name).' Gagal!</b>';
}
echo '<br/><a href="admin.php?iwb=iwb_market">Kembali</a></p>';
unlink($unziper_file);
}
else
{
echo '<p><strong>'.htmlspecialchars($name).'</strong> Gagal diinstall secara otomatis.<br/><a href="admin.php?iwb=iwb_market">Kembali</a></p>';
}
}
else
{
if (!file_exists($location))
{
echo '<form method="post" action="admin.php?iwb=iwb_market&amp;action=install&amp;name='.base64_encode($name).'&amp;location='.base64_encode($location).'&amp;modul='.base64_encode($modul).'&amp;sql='.base64_encode($sql).'">Anda yakin akan menginstall <b>'.$name.'</b>?<br><br><div class="two-col-btn"><input class="iwb-button" type="submit" name="yes" value="Ya"/><input class="iwb-button" type="submit" name="no" value="Tidak"/></div></form>';
}else{
echo '<form method="post" action="admin.php?iwb=iwb_market&amp;action=install&amp;name='.base64_encode($name).'&amp;location='.base64_encode($location).'&amp;modul='.base64_encode($modul).'&amp;sql='.base64_encode($sql).'">Sebelumnya <b>'.$name.'</b> telah diinstall.<br>';
if (!empty($sql))
echo 'Penginstallan ulang mungkin akan menghapus data mysql sebelumnya dan menggantikan dengan data mysql yang baru.<br/>';
echo 'Apakah Anda akan menginstall ulang?<br><br><div class="two-col-btn"><input class="iwb-button" type="submit" name="yes" value="Ya"/><input class="iwb-button" type="submit" name="no" value="Tidak"/></div></form>';
}
}
echo '</div></div>';
include 'foot.php';
break;

default:
if (!$user_id)
relogin();

if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$head_title='IWB Market';
include 'head.php';
echo '<div id="message">';
if (!empty($error_install))
echo $error_install;
echo '</div>';
echo '<div id="content">
<div id="main-content">';

$search=htmlentities($_GET['search']);
$publisher=htmlentities($_GET['publisher']);
$buy=htmlentities($_GET['buy']);
$has_been_tested=htmlentities($_GET['has_been_tested']);
$untested=htmlentities($_GET['untested']);
$premium=htmlentities($_GET['premium']);
$free=htmlentities($_GET['free']);
$page=htmlentities($_GET['page']);
if(empty($page))
$page='1';
if (isset($_GET['search']))
{
$feed='http://indowapblog.com/iwb_market.php?search='.$search.'&page='.$page.'';
}
elseif (isset($_GET['has_been_tested']))
{
$feed='http://indowapblog.com/iwb_market.php?has_been_tested='.$has_been_tested.'&page='.$page.'';
}
elseif (isset($_GET['untested']))
{
$feed='http://indowapblog.com/iwb_market.php?untested='.$untested.'&page='.$page.'';
}
elseif (isset($_GET['buy']))
{
$feed='http://indowapblog.com/iwb_market.php?buy='.$buy.'';
}
elseif (isset($_GET['publisher']))
{
$feed='http://indowapblog.com/iwb_market.php?publisher='.$publisher.'&page='.$page.'';
}
elseif (isset($_GET['free']))
{
$feed='http://indowapblog.com/iwb_market.php?free='.$free.'&page='.$page.'';
}
elseif (isset($_GET['premium']))
{
$feed='http://indowapblog.com/iwb_market.php?premium='.$premium.'&page='.$page.'';
}
else
{
$feed='http://indowapblog.com/iwb_market.php?page='.$page.'';
}
$howmany='5';

$uag = $_SERVER['HTTP_USER_AGENT'];

ini_set('user_agent',$uag."\r\naccept: text/html, application/xml;q=0.9, application/xhtml+xml, image/png, image/jpeg, image/gif, image/x-xbitmap, */*;q=0.1\r\naccept_charset: $_SERVER[HTTP_ACCEPT_CHARSET]\r\naccept_language: $_SERVER[HTTP_ACCEPT_LANGUAGE]");

if ($xml = simplexml_load_file($feed))
{
foreach ($xml->channel->item as $item)
{
if (!$count)
$count='1';
else
$count=$count+1;

if ($count>$howmany)
$howmany=$count;
if ($count<=$howmany)
{
$title = $item->title;
if ($title)
{
$title = $item->title;
$link=htmlspecialchars($item->link);$tgl = strtotime($item->pubDate);
$desc = $item->description;
$st_url='_SITE_URL_';
$st_name='_SITE_NAME_';
$desc=str_replace($st_url,$site['url'],str_replace($st_name,$site['name'],$desc));
echo html_entity_decode(htmlentities($desc));
}
}
}
}
else
{
echo '<p>Tidak bisa menampilkan data</p>';
}
echo '</div></div>';
include 'foot.php';
}
?>