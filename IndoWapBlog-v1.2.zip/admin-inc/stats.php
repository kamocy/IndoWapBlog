<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');

if (!$user_id)
relogin();

if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$page=$_GET['page'];
if ($page=='0')
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;
$head_title='Statistik Pengunjung';
include 'head.php';
echo '<div id="message">';
echo '</div>';
echo '<div id="content">
<div id="main-content">';
$all=mysql_fetch_array(mysql_query("select sum(total) as totals from stats"));
echo '<div id="show_bar">Total Pengunjung : '.$all['totals'].'</div>';
echo '<ol>';
$req=mysql_query("select * from stats order by time desc limit $limit,$max_view");
while ($res=mysql_fetch_array($req))
{
echo $i % 2 ? '<li class="row1">' : '<li class="row0">';
echo '<strong>Tanggal</strong> : '.$res['time'].'<br/><strong>Pengunjung</strong> : '.$res['total'].'';
++$i;
echo '</li>';
}
echo '</ol></div>';
$total=mysql_result(mysql_query("select count(*) as num from stats"), 0);
$link='admin.php?iwb=stats&amp;page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
echo '</div>';
include 'foot.php';
?>