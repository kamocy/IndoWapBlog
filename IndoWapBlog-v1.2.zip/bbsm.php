<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

define('_IWB_', 1);

include 'indowapblog.php';
$iwb=isset($_GET['iwb']) ? trim($_GET['iwb']) : '';

switch ($iwb)
{
case 'bbcode':
$head_title='BBCode';
include 'head.php';
echo '<div id="message">';
echo '</div>
<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="bbsm.php?iwb=smiley">Smiley</a> | BBCode</div><ol>';

echo '<li class="row1"><b>Kode:</b> [textarea]'.$site['name'].'[/textarea]<br/><b>Hasil:</b> '.bbsm('[textarea]'.$site['name'].'[/textarea]').'</li>';

echo '<li class="row0"><b>Kode:</b> [color=blue]Warna Biru[/color]<br/><b>Hasil:</b> '.bbsm('[color=blue]Warna Biru[/color]').'</li>';

echo '<li class="row1"><b>Kode:</b> [b]Teks Tebal[/b]<br/><b>Hasil:</b> '.bbsm('[b]Teks Tebal[/b]').'</li>';

echo '<li class="row0"><b>Kode:</b> [i]Teks Miring[/i]<br/><b>Hasil:</b> '.bbsm('[i]Teks Miring[/i]').'</li>';

echo '<li class="row1"><b>Kode:</b> [u]Teks Garis Bawah[/u]<br/><b>Hasil:</b> '.bbsm('[u]Teks Garis Bawah[/u]').'</li>';

echo '<li class="row0"><b>Kode:</b> [url]'.$site['url'].'[/url]<br/><b>Hasil:</b> '.bbsm('[url]'.$site['url'].'[/url]').'</li>';

echo '<li class="row1"><b>Kode:</b> [url='.$site['url'].']'.$site['name'].'[/url]<br/><b>Hasil:</b> '.bbsm('[url='.$site['url'].']'.$site['name'].'[/url]').'</li>';
echo '</ol></div></div>';
include 'foot.php';
break;

case 'smiley':
default:
$page=$_GET['page'];
if ($page=='0')
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;

$maxsize='5000';
$filename=strtolower($_FILES['file']['name']);

if (isset($_POST['upload']))
{
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$types = array("image/jpeg", "image/pjpeg","image/gif","image/x-png");
if (!in_array($_FILES['file']['type'], $types))
$hsl='<ol id="error"><li>Jenis file tidak diijinkan</li></ol>';
if ($_FILES['file']['size'] > (1024*$maxsize))
$hsl='<ol id="error"><li>File maksimal berukuran 5Mb</li></ol>';
$newName=substr($filename,0,-4);
if (empty($filename))
$hsl='<ol id="error"><li>Silakan pilih file</li></ol>';

if (empty($hsl))
{
copy($_FILES['file']['tmp_name'], "images/smiley/$newName.gif");
$hsl='<ol id="success"><li><b>'.$newName.'</b> berhasil diupload</li></ol>';
}
}
$head_title='Smileys';
include 'head.php';
echo '<div id="message">';
if (!empty($hsl))
echo $hsl;
echo '</div>
<div id="content">
<div id="main-content">';
echo '<div id="show_bar">Smiley | <a href="bbsm.php?iwb=bbcode">BBCode</a></div>';

if ($is_admin)
{
echo '<form action="bbsm.php?iwb=smiley" method="post" enctype="multipart/form-data">
    <input name="MAX_FILE_SIZE" value="5242880" type="hidden"/>
    <h4>Pilih File</h4>
<input type="file" name="file"/>
    <input class="iwb-button" name="upload" type="submit" value="Upload"/></form>';
}
if (($is_admin) && ($_GET['action'] == 'update'))
{
mysql_query("delete from `replace_text` where `type`='smiley'");
$arr=array(".gif",".jpg",".png");
foreach (glob("images/smiley/*") as $file)
{
$files=basename($file);
$fl[] =$files;
$nm=substr($files,-4);
$name=substr($files,0,-4);
if (in_array($nm, $arr))
{
$key=':'.$name.':';
$val='<img src="'.$site_url.'/images/smiley/'.$files.'" alt=""/>';
mysql_query("insert into `replace_text` set `key`='".mysql_real_escape_string($key)."', `value`='".mysql_real_escape_string($val)."', `type`='smiley'") or die(mysql_error());
}
}
$total=count($fl);
echo '<p>Telah diperbarui sebanyak '.$total.' smileys.<br/><a href="bbsm.php?iwb=smiley">Kembali</a></p>';
}
else
{
echo '<ol>';
$req=mysql_query("select * from `replace_text` where `type`='smiley' order by `id` desc limit $limit,$max_view");
while ($res=mysql_fetch_array($req))
{
echo $i % 2 ? '<li class="row1">' : '<li class="row0">';
echo ''.html_entity_decode($res['value']).'<br/><b>'.$res['key'].'</b>';
++$i;
echo '</li>';
}
echo '</ol>';

if ($is_admin)
echo '<a href="bbsm.php?iwb=smiley&amp;action=update"><input class="iwb-button" type="submit" value="Perbarui Smiley"/></a>';
}
echo '</div>';
$total=mysql_result(mysql_query("select count(*) as num from `replace_text` where `type`='smiley'"), 0);
$link='bbsm.php?iwb=smiley&amp;page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
echo '</div>';
include 'foot.php';
}
?>
