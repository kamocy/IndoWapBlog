<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

defined('_IWB_') or die ('Kesalahan: pembatasan akses');
echo '<div id="footer">';
$t_day=date('d-m-Y', time());
$qr=mysql_query("select total from stats where time='$t_day'");
$Qr=mysql_fetch_array($qr);
$new_count = $Qr['total'] + 1;
if (mysql_num_rows($qr) == 0)
{
mysql_query("insert into stats set total='1', time='$t_day'");
}
else
{
mysql_query("update stats set total='$new_count' where time='$t_day'");
}

if ($site['display_count'] == 1)
{
$ol = time() - 300;

$user_ol=mysql_result(mysql_query("SELECT COUNT(*) FROM user WHERE lastdate > $ol"), 0);

$guest_ol=mysql_result(mysql_query("SELECT COUNT(*) FROM guest WHERE lastdate > $ol"), 0);
echo 'Online : <span style="background: #333333; padding: 2px; border: 2px dashed #dddddd; color: #ffffff;"><a href="'.$site['url'].'/online.php">'.$user_ol.'/'.$guest_ol.'</a></span><br/>';
$t_all=mysql_fetch_array(mysql_query("select sum(total) as total from stats"));

echo 'Total Pengunjung: <span style="background: #333333; padding: 2px; border: 2px dashed #dddddd; color: #ffffff;">'.$t_all['total'].'</span><br/>';
}
echo '&copy; '.date('Y',time()).' <a href="'.$site['url'].'">'.$site['name'].'</a>
<br/>Powered by <a href="http://indowapblog.com">IndoWapBlog.com</a></div></body></html>';
following_reader();
mysql_close($iwb_connect);
?>