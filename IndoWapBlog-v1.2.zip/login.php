<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

define('_IWB_', 1);

$iwb=isset($_GET['iwb']) ? trim($_GET['iwb']) : '';
switch ($iwb)
{
case 'conf':
include 'indowapblog.php';
if (isset($_GET['code']))
{
$kode=$_GET['code'];
$cek=mysql_query("select * from user where substr(confirm,-6)='".mysql_real_escape_string($kode)."' limit 1;") or die(mysql_error());
if (mysql_num_rows($cek) == 0)
{
$err='<ol id="error"><li>Kode konfirmasi salah</li><ol>';
}
else
{
$res=mysql_fetch_array($cek);
mysql_query("update user set password='".substr($res['confirm'],0,32)."', confirm='0' where id='".$res['id']."'");
$head_title='Konfirmasi Kata Sandi';
include 'head.php';
echo '<div id="message"></div><div id="content"><div id="main-content">';
echo '<div id="show_bar"><a href="login.php">Masuk</a> | <a href="login.php?iwb=lost_password">Lupa Sandi</a> | Konfirmasi</div>';
echo '<p>Kata Sandi baru berhasil dikonfirmasikan. Silakan <a href="login.php">Masuk di sini</a></p>';
echo '</div></div>';
include 'foot.php';
exit;
}
}
$head_title='Konfirmasi Kata Sandi';
include 'head.php';
echo '<div id="message">';
if (!empty($err))
echo $err;
echo '</div><div id="content"><div id="main-content">';
echo '<div id="show_bar"><a href="login.php">Masuk</a> | <a href="login.php?iwb=lost_password">Lupa Sandi</a> | Konfirmasi</div>';
echo '<form method="get" action="login.php"><input type="hidden" name="iwb" value="conf"/><h4>Kode</h4><input class="iwb-text" name="code" type="text" maxlength="6" size="30"/><br/><p align="center"><input class="iwb-button" type="submit" value="Konfirmasi"/></p></form>';
echo '</div></div>';
include 'foot.php';

break;
case 'lost_password':
include 'indowapblog.php';
if ($user_id)
header('location: dashboard.php');
if (isset($_POST['send']))
{
if ($user_id)
header('location: dashboard.php');

$login=$_POST['log'];
$pw=$_POST['pass'];
$rpw=$_POST['re_pass'];
$code=$_POST['code'];
if ($code != $_SESSION['captcha_code'])
$err='Kode keamanan salah';
$cek=mysql_query("select * from user where username='".mysql_real_escape_string($login)."' or email='".mysql_real_escape_string($login)."'");
if (mysql_num_rows($cek) == 0)
$err='Username atau Email &quot;<strong>'.htmlspecialchars($login).'</strong>&quot; tidak ada pada data Kami.';
$us=mysql_fetch_array($cek);
if (empty($us['email']))
$err='Maaf pengguna ini tidak mencantumkan email pada data profilnya. Harap hubungi administrator <strong>'.htmlspecialchars($site['name']).'</strong>';
if (mb_strlen($pw) > 16 || mb_strlen($pw) < 4)
$err='Kata sandi minimal 4 dan maksimal 16 karakter';
elseif (empty($pw) || empty($rpw))
$err='Silakan masukan kata sandi baru';
if ($pw != $rpw)
$err='Kata sandi tidak sama';
if (empty($err))
{
$pwd=md5($pw);
$kode=rand(100000, 999999);
$lp=''.$pwd.$kode.'';
mysql_query("update user set confirm='".$lp."' where id='".$us['id']."'");
$adm=mysql_fetch_array(mysql_query("select * from user where admin='1' limit 1;"));

$email = $us['email'];
$subject="Konfirmasi Sandi baru ".$site['name']."";
$pesan="Berikut adalah Data Akun Anda\r\n\r\n";
$pesan .= "\r\n\r\n";
$pesan .= "Username: ".$us['username']."";
$pesan .= "\r\n\r\n";
$pesan .= "Kata Sandi: ".$pw."";
$pesan .= "\r\n\r\n";
$pesan .= "Kode Konfirmasi: ".$kode."";
$pesan .= "\r\n\r\n";
$pesan .= "\r\n\r\nSilakan pergi ke ".$site['url']."/login.php?iwb=conf dan masukan kode konfirmasi atau klik link di bawah ini\r\n\r\n";
$pesan .= "\r\n\r\n";
$pesan .= ''.$site['url'].'/login.php?iwb=conf&code='.$kode.'';$pesan .= "\r\n\r\n";
$pesan .= "\r\nTerima Kasih\r\n";
$pesan .= $site['name'];
$pesan .= "\r\n\r\n";
$pesan .= $site['url'];
$dari = "From: ".$site['name']." <".$adm['email'].">\r\n";
$dari .= "X-sender: ".$site['name']." <".$adm['email'].">\r\n";
$dari .= "Content-type:text/plain; charset=iso-8859-1\r\n";
$dari .= "MIME-Version: 1.0\r\n";
$dari .= "Content-Transfer-Encoding: 8bit\r\n";
$dari .= "X-Mailer: PHP v.".phpversion();
mail($email,$subject,$pesan,$dari);
$head_title='Lupa Kata Sandi';
include 'head.php';
echo '<div id="message"></div><diu id="content"><diu id="main-content"><p>Link konfirmasi telah kami kirim ke Email Anda. Silakan klik link konfirmasi tersebut</p></div>';
echo '</div>';
include 'foot.php';
exit;
}
else
{
$hsl='<ol id="error"><li>'.$err.'</li></ol>';
}
}

$head_title='Lupa Kata Sandi';
include 'head.php';
echo '<div id="message">';
if (!empty($hsl))
echo $hsl;
echo '</div><div id="content"><div id="main-content">';
echo '<div id="show_bar"><a href="login.php">Masuk</a> | Lupa Sandi | <a href="login.php?iwb=conf">Konfirmasi</a></div>';
echo '<form method="post" action="login.php?iwb=lost_password"><h4>Username atau Email</h4><input class="iwb-text" name="log" type="text" size="30"/><br/><h4>Kata sandi baru</h4>
<input class="iwb-password" name="pass" type="password" maxlength="16" size="30"/><br/>
<h4>Ulangi Kata sandi baru</h4>
<input class="iwb-password" name="re_pass" type="password" maxlength="16" size="30"/><br/>';
$_SESSION['captcha_code'] = strval(rand(1000, 9999));
echo '<h4>Kode keamanan:</h4><img src="captcha.php" alt=""/><br /><input class="iwb-text" type="text" name="code" value=""/><p align="center"><input class="iwb-button" name="send" type="submit" value="Kirim"/></p></form></div></div>';
include 'foot.php';
break;

case 'logout':
session_name('IndoWapBlog');
session_start();
setcookie('user_id', '');
setcookie('password', '');
session_destroy();
header('Location: login.php');
break;


default:
include 'indowapblog.php';
$redir=$_GET['redir'];
if (empty($redir))
$redir=$_POST['redir'];
if (empty($redir))
$redir=base64_encode('dashboard.php');
$redirect=base64_decode($redir);
if ($user_id)
header('location: '.$redirect.'');
if (isset($_POST['login']))
{if ($user_id)
header('location: '.$redirect.'');

$login=$_POST['log'];
$password=md5($_POST['password']);
$cek=mysql_query("SELECT * FROM `user` WHERE `username`='".mysql_real_escape_string($login)."' OR `email`='".mysql_real_escape_string($login)."'");

if (mysql_num_rows($cek) == 0)
{
$error='Username atau Email tidak benar';
}
else
{
$user=mysql_fetch_array($cek);
if ($user['password'] != $password)
{
$error='Kata sandi tidak benar';
}
else
{
$user_id = $user['id'];
setcookie("user_id", $user_id, time() +60 * 60 * 24 * 30);
setcookie("password", $password, time() +60 * 60 * 24 * 30);
mysql_query("update user set lastdate='".time()."', ip_proxy='".mysql_real_escape_string($_SERVER['REMOTE_ADDR'])."', ip_browser='".mysql_real_escape_string($_SERVER['HTTP_X_FORWARDED_FOR'])."', user_agent='".mysql_real_escape_string($_SERVER['HTTP_USER_AGENT'])."' where id='".$user['id']."'");
 
header('location: '.$redirect.'');
}
}
}

$head_title='Masuk';
include 'head.php';
echo '<div id="message">';
if (!empty($error))
echo '<ol id="error"><li>'.$error.'</li></ol>';
if (isset($_GET['redir']))
echo '<ol id="notice"><li>Anda harus masuk dahulu.</li></ol>';
echo '</div><div id="content"><div id="main-content">';
echo '<div id="show_bar">Masuk | <a href="login.php?iwb=lost_password">Lupa Sandi</a> | <a href="login.php?iwb=conf">Konfirmasi</a></div>';
echo '<p>Pengguna baru? <a href="register.php">Daftar di sini!</a>';
echo '</p><form method="post" action="login.php"><h4>Username atau Email</h4><input class="iwb-text" name="log" type="text" size="30"/><br/><input name="remember" type="hidden" value="yes"/><input name="redir" type="hidden" value=""/><h4>Kata sandi</h4><input class="iwb-password" name="password" type="password" maxlength="12" size="30"/><input type="hidden" name="redir" value="'.$redir.'"/><br/><a href="login.php?iwb=lost_password" rel="nofollow">Lupa kata sandi?</a><p align="center"><input class="iwb-button" name="login" type="submit" value="Masuk"/></p></form></div></div>';
include 'foot.php';
}
?>
