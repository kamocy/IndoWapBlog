<?php

//******************Nama Script: IndoWapBlog***********************************Versi: (Lihat VERSION.txt)***********************************Pembuat: Achunk JealousMan***********************************Kontak: achunk17[at]gmail[dot]com***********************************Situs: http://achunk.jw.lt***********************************Facebook: http://www.facebook.com/achunks*****************//

define('_IWB_', 1);

include 'indowapblog.php';
$rd='http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].'';
$rd=base64_encode($rd);
$iwb=isset($_GET['iwb']) ? trim($_GET['iwb']) : '';
switch ($iwb)
{
case 'delete':
$comid=$_GET['comid'];
$all=$_GET['all'];
if ($all == 'spam')
$sts='2';
if ($all == 'unapproved')
$sts='0';
if ($all == 'approved')
$sts='1';
$redir=$_GET['redir'];
$back=base64_decode($redir);
if (!$user_id)
relogin();
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
if (isset($_GET['yes']))
{
$redir=base64_decode($_GET['redir']);
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
//*Menghapus semua komentar *//
if ($all)
mysql_query("delete from guestbook where status='".$sts."'");

//*Menghapus satu pesan yang dipilih*//
if ($comid)
mysql_query("delete from guestbook where id='".mysql_real_escape_string($comid)."'");

//*Redirect*//
header('location: '.$redir.'');
}
$head_title='Hapus Pesan Buku Tamu';
include 'head.php';
echo '<div id="message"><ol id="notice"><li>';

if ($all == 'approved')
echo 'Anda yakin ingin menghapus semua pesan yang telah disetujui pada Guestbook?<br/>[<a href="manage_guestbook.php?iwb=delete&amp;all='.$all.'&amp;yes=&amp;redir='.$redir.'">YA</a>] [<a href="'.$back.'">TIDAK</a>]';

if ($all == 'unapproved')
echo 'Anda yakin ingin menghapus semua pesan yang belum disetujui pada Guestbook?<br/>[<a href="manage_guestbook.php?iwb=delete&amp;all='.$all.'&amp;yes=&amp;redir='.$redir.'">YA</a>] [<a href="'.$back.'">TIDAK</a>]';

if ($all == 'spam')
echo 'Anda yakin ingin menghapus semua pesan Spam pada Guestbook?<br/>[<a href="manage_guestbook.php?iwb=delete&amp;all='.$all.'&amp;yes=&amp;redir='.$redir.'">YA</a>] [<a href="'.$back.'">TIDAK</a>]';

if ($comid)
echo 'Anda yakin ingin menghapus pesan ini pada Guestbook?<br/>[<a href="manage_guestbook.php?iwb=delete&amp;comid='.$comid.'&amp;yes=&amp;redir='.$redir.'">YA</a>] [<a href="'.$back.'">TIDAK</a>]';

echo '</li></ol></div>';
include 'foot.php';
break;



case 'approved':
case 'unapproved':
case 'spam':
$comid=$_GET['comid'];
$in=$_GET['iwb'];

if ($in == 'approved')
$status='1';
if ($in == 'unapproved')
$status='0';
if ($in == 'spam')
$status='2';


if (isset($_GET['comid']))
{
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$redir=$_GET['redir'];
$redir=base64_decode($redir);

mysql_query("update guestbook set status='".$status."' where id='".mysql_real_escape_string($comid)."'");
header('location: '.$redir.'');
}


if (!$user_id)
relogin();
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$page=$_GET['page'];
if ($page=='0')
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;

if ($in == 'unapproved')
$head_title='Ditangguhkan';
if ($in == 'approved')
$head_title='Disetujui';
if ($in == 'spam')
$head_title='Spam';

include 'head.php';
echo '<div id="message">
</div>
<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="manage_guestbook.php">Semua</a> | ';
if ($in == 'approved')
echo 'Disetujui';
else
echo '<a href="manage_guestbook.php?iwb=approved">Disetujui</a>';
echo ' |
';
if ($in == 'unapproved')
echo 'Ditangguhkan';
else
echo '<a href="manage_guestbook.php?iwb=unapproved">Ditangguhkan</a>';
echo ' | ';
if ($in == 'spam')
echo 'Spam';
else
echo '<a href="manage_guestbook.php?iwb=spam">Spam</a>';
echo '</div>';
echo '<ol>';
$count=mysql_result(mysql_query("select count(*) as num from guestbook where status='".$status."'"), 0);
$req=mysql_query("select * from guestbook where status ='".$status."' order by time desc limit $limit,$max_view");
while ($com=mysql_fetch_array($req))
{
echo $i % 2 ? '<li class="row1">' : '<li class="row0">';
echo '<a href="'.$com['site'].'/" accesskey="1">'.htmlspecialchars($com['name']).'</a><br/>['.waktu($com['time']).']<br/>'.bbsm($com['text']).'<br/><span class="action_links">';
if ($com['status'] == 1)
echo '[<a class="reply" href="manage_guestbook.php?iwb=reply&amp;comid='.$com['id'].'">Balas</a>] ';
if ($com['status'] == 0)
echo '[<font color="black">Tangguhkan</font>] ';
else
echo '[<a href="manage_guestbook.php?iwb=unapproved&amp;comid='.$com['id'].'&amp;redir='.$rd.'">Tangguhkan</a>] ';

if ($com['status'] == 1)
echo '[<font color="black">Setujui</font>] ';
else
echo '[<a href="manage_guestbook.php?iwb=approved&amp;comid='.$com['id'].'&amp;redir='.$rd.'">Setujui</a>] ';

if ($com['status'] == 2)
echo '[<font color="black">Spam</font>] ';
else
echo '[<a href="manage_guestbook.php?iwb=spam&amp;comid='.$com['id'].'&amp;redir='.$rd.'">Spam</a>] ';

echo '[<a class="delete" href="manage_guestbook.php?iwb=delete&amp;comid='.$com['id'].'&amp;redir='.$rd.'"><font color="red">Hapus</font></a>]</span>';
++$i;
echo '</li>';
}

if ($count == 0)
echo '<p>Anda belum memiliki pesan buku tamu yang '.htmlspecialchars($head_title).'</p>';
else
echo '<p><a href="manage_guestbook.php?iwb=delete&amp;all='.$in.'&amp;redir='.$rd.'"><input class="iwb-button" type="submit" value="Hapus semua pesan"/></a></p>';
echo '</ol></div>';
$total=$count;
if ($in == 'approved')
$link='manage_guestbook.php?iwb=approved&amp;page=';
elseif ($in == 'unapproved')
$link='manage_guestbook.php?iwb=unapproved&amp;page=';
else
$link='manage_guestbook.php?iwb=spam&amp;page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
echo '</div>';
include 'foot.php';


break;
case 'reply':
$comid=$_GET['comid'];
$reply=$_POST['reply'];
if (!$user_id)
relogin();
$req=mysql_query("select * from guestbook where id='".mysql_real_escape_string($comid)."'");
if (mysql_num_rows($req) == 0)
{
include 'head.php';
page_not_found();
include 'foot.php';
exit;
}
$res=mysql_fetch_array($req);
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
if (isset($_POST['send']))
{
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
if (mb_strlen($reply) > 500)
$hsl='Pesan maksimal 500 karakter';
elseif (empty($reply))
$hsl='Silakan tulis komentar Anda';
if (empty($hsl))
{
mysql_query("insert into guestbook set user_id='".$user_id."', name='".mysql_real_escape_string($user_name)."', site='".$site['url']."/user.php?id=".$user_id."', text='".mysql_real_escape_string($reply)."', status='1', time='".time()."'");
header('location: manage_guestbook.php?reply_successfully');
}
}
$head_title='Balas Buku Tamu';
include 'head.php';
echo '<div id="message">
</div>
<div id="content">
<div id="main-content">';
echo '<div id="show_bar"><a href="manage_guestbook.php?">Semua</a> | <a href="manage_guestbook.php?iwb=approved">Disetujui</a> |
<a href="manage_guestbook.php?iwb=unapproved">Ditangguhkan</a> | <a href="manage_guestbook.php?iwb=spam">Spam</a></div>';

echo '<h4>Balas pesan buku tamu </h4>
<p class="row0">';
if ($res['user_id'] != 0)
{
echo '<strong><a href="'.$site['url'].'/user.php?id='.$res['user_id'].'">'.htmlspecialchars($res['name']).'</a></strong>';
}
else
{
echo '<strong>'.htmlspecialchars($res['name']).'</strong>';
}
echo '<br/>['.waktu($res['time']).']<br/>'.bbsm($res['text']).'</p>
<form action="manage_guestbook.php?iwb=reply&amp;comid='.$res['id'].'" method="post"><h4>Balas</h4>
<textarea class="iwb-textarea" name="reply" rows="5" cols="30">@'.htmlentities($res['name']).',
</textarea><br/>
<input class="iwb-button" name="send" type="submit" value="Kirim"/>';
echo '</div></div>';
include 'foot.php';
break;

default:
$page=$_GET['page'];
if ($page=='0')
$page='1';
$page--;
$max_view=$site['num_post_main'];
$limit=$page*$max_view;
$page++;if (!$user_id)
relogin();
if (!$is_admin)
{
include 'head.php';
forbidden();
include 'foot.php';
exit;
}
$count=mysql_result(mysql_query("select count(*) from guestbook"), 0);
$req=mysql_query("select * from guestbook order by time desc limit $limit,$max_view");
$head_title='Kelola Buku Tamu';
include 'head.php';
echo '<div id="message">
</div>
<div id="content">
<div id="main-content">';
echo '<div id="show_bar">';
echo 'Semua';
echo ' | <a href="manage_guestbook.php?iwb=approved">Disetujui</a> |
<a href="manage_guestbook.php?iwb=unapproved">Ditangguhkan</a> | <a href="manage_guestbook.php?iwb=spam">Spam</a></div>';
echo '<ol>';
while ($com=mysql_fetch_array($req))
{
echo $i % 2 ? '<li class="row1">' : '<li class="row0">';
echo '<a href="'.htmlentities($com['site']).'/">'.htmlspecialchars($com['name']).'</a><br/>['.waktu($com['time']).']<br/>'.bbsm($com['text']).'<br/><span class="action_links">';
if ($com['status'] == 1)
echo '[<a class="reply" href="manage_guestbook.php?iwb=reply&amp;comid='.$com['id'].'">Balas</a>] ';
if ($com['status'] == 0)
echo '[<font color="black">Tangguhkan</font>] ';
else
echo '[<a href="manage_guestbook.php?iwb=unapproved&amp;comid='.$com['id'].'&amp;redir='.$rd.'">Tangguhkan</a>] ';

if ($com['status'] == 1)
echo '[<font color="black">Setujui</font>] ';
else
echo '[<a href="manage_guestbook.php?iwb=approved&amp;comid='.$com['id'].'&amp;redir='.$rd.'">Setujui</a>] ';

if ($com['status'] == 2)
echo '[<font color="black">Spam</font>] ';
else
echo '[<a href="manage_guestbook.php?iwb=spam&amp;comid='.$com['id'].'&amp;redir='.$rd.'">Spam</a>] ';
echo '[<a class="delete" href="manage_guestbook.php?iwb=delete&amp;comid='.$com['id'].'&amp;redir='.$rd.'"><font color="red">Hapus</font></a>]</span>';
++$i;
echo '</li>';
}
if ($count == 0)
{
echo '<li>Guestbook kosong';
echo '</li>';
}
echo '</ol></div>';
$total=$count;
$link='manage_guestbook.php?page=';
$q='';
pagination($page,$max_view,$total,$link,$q);
echo '</div>';
include 'foot.php';
}?>